"use client";

import { useCallback, useEffect, useState } from "react";
import {
  ArrowRight,
  BadgeCheck,
  ChevronDown,
  Download,
  FileJson,
  Link2,
  ListChecks,
  RefreshCw,
  ScrollText,
  ShieldCheck,
  Table2,
} from "lucide-react";
import type { AuthenticatedUser } from "@/components/auth-entry";
import { ProfileDialog } from "@/components/profile-dialog";
import { SettingsDialog } from "@/components/settings-dialog";
import { WorkspaceHeader } from "@/components/workspace-header";

type RunSummary = {
  id: string;
  status: string;
  revisionRound: number;
  riskLevel: string;
  finalAssetId: string | null;
  task: string;
  resourceType: string;
  createdAt: number;
  finishedAt: number | null;
};

function runDisplayState(run: RunSummary): { status: string; publication: string; tone: string } {
  if (run.status === "queued") return { status: "等待执行", publication: "尚未开始生成", tone: "bg-amber-100 text-amber-700" };
  if (run.status === "running") return { status: "生成中", publication: "正在处理，尚未发布", tone: "bg-blue-100 text-blue-700" };
  if (run.status === "cancelled") return { status: "已取消", publication: "本次未生成资源", tone: "bg-muted text-muted-foreground" };
  if (run.status === "failed") return { status: "处理失败", publication: "未生成资源", tone: "bg-destructive/10 text-destructive" };
  if (run.finalAssetId) return { status: "已发布", publication: "资源已入库", tone: "bg-emerald-100 text-emerald-700" };
  return { status: "已收起", publication: "系统已收起未达标草稿", tone: "bg-slate-100 text-slate-700" };
}

type TraceArtifact = {
  id: string;
  nodeKey: string;
  actorKey: string;
  attempt: number;
  artifactType: string;
  inputRefs: string[];
  payload: Record<string, unknown>;
  publicRationale: { observations: string[]; basisRefs: string[]; decision: string; uncertainty: string[]; nextAction: string | null };
  producer: { kind: string; model: string | null; promptHash: string | null; settingsHash: string | null };
  contentHash: string;
  createdAt: number;
};

type ClaimStage = { attempt: number; claimId: string; text: string; verdict: string; critique: string; claimType: string | null; evidence: Array<{ evidenceId: string; supportLevel: string }>; supersedesClaimId: string | null };

type TraceData = {
  run: { id: string; status: string; revisionRound: number; riskLevel: string; finalAssetId: string | null; createdAt: number; startedAt: number | null; finishedAt: number | null; executionManifestHash?: string | null };
  plan: { nodes: Array<{ key: string; dependsOn: string[]; mandatory: boolean }>; gates: string[] };
  verificationPolicy: { coverageStatus?: string; strength?: string; reasons?: string[] } | null;
  nodes: Array<{ nodeKey: string; role: string; attempt: number; status: string; mandatory: boolean; startedAt: number | null; finishedAt: number | null; resultSummary: string | null }>;
  artifacts: TraceArtifact[];
  claimGraph: Array<{ id: string; attempt: number | null; text: string; verdict: string; claimType: string | null; evidence: Array<{ evidenceId: string }> }>;
  debateIssues: Array<{ id: string; issueType: string; argument: string; source: string; status: string }>;
  auditDecisions: Array<{ round: number; verdict: string; released: boolean; rationale: string }>;
  claimTrace: Array<{
    logicalKey: string | null;
    auditable: boolean;
    claimType: string | null;
    stages: ClaimStage[];
    issues: Array<{ attempt: number; issueType: string; argument: string; source: string; status: string }>;
    finalAttempt: number;
    finalVerdict: string | null;
  }>;
  snapshots: { runStart: unknown; generationEnd: unknown };
};

type VerifyResult = {
  integrity: { passed: boolean; checks: Array<{ id: string; label: string; passed: boolean; detail: string }> };
  manifestHash: string | null;
  manifestMatchesOnline: boolean | null;
  replay: { passed: boolean; attempts: Array<{ attempt: number; auditableClaims: number; unsupportedClaims: number; hallucinationRate: number | null; ruleGate: string; recordedVerdict: string | null; match: boolean }>; draftFinal: { draftRate: number | null; finalRate: number | null; gateNetGain: number | null }; differences: string[] };
};

const ACTOR_LABELS: Record<string, string> = {
  learner_modeler: "学情建模者",
  structured_retriever: "结构化检索者",
  document_retriever: "文档检索者",
  domain_analyst: "领域分析者",
  resource_author: "资源作者",
  claim_auditor: "声明审核者",
  red_team_critic: "反方质询者",
  evidence_judge: "证据裁决者",
  privacy_guard: "隐私守门人",
  publisher: "发布者",
};

const NODE_LABELS: Record<string, string> = {
  "assess.learner": "学情建模",
  "retrieve.structured": "结构化证据检索",
  "retrieve.document": "文档证据检索",
  "analyze.domain": "领域分析",
  "generate.resource": "资源生成",
  "audit.claims": "逐条检查内容",
  "debate.challenge": "检查疑点",
  "adjudicate.verdict": "判断证据是否足够",
  "privacy.compliance": "隐私检查",
  "finalize.publish": "整理并保存结果",
};

const ARTIFACT_LABELS: Record<string, string> = {
  learner_snapshot: "画像记录",
  evidence_set: "证据集合",
  domain_brief: "领域分析",
  resource_draft: "资源初稿",
  claim_audit: "内容检查",
  challenge_set: "疑点检查",
  adjudication: "证据判断",
  privacy_decision: "隐私检查",
  publication_decision: "发布决定",
};

const RESOURCE_LABELS: Record<string, string> = {
  lecture: "讲义", tiered_quiz: "分层习题", presentation: "PPT", concept_map: "知识脉络",
};

function readableAuditText(text: string): string {
  return text
    .replace(/manual_review_required/g, "系统已收起")
    .replace(/revision budget/gi, "修改次数")
    .replace(/revised|revision/gi, "需要修改")
    .replace(/rejected/gi, "未通过")
    .replace(/released/gi, "已通过")
    .replace(/unsupported/gi, "缺少依据")
    .replace(/partial/gi, "部分支持")
    .replace(/conflict/gi, "相互矛盾")
    .replace(/review/gi, "需更多依据")
    .replace(/strict/gi, "从严检查")
    .replace(/standard/gi, "标准检查")
    .replace(/DAG/g, "处理流程")
    .replace(/Claim/g, "内容")
    .replace(/Agent/g, "智能体")
    .replace(/反方质询/g, "疑点检查")
    .replace(/待复核/g, "需更多依据")
    .replace(/复核疑点/g, "检查疑点")
    .replace(/证据裁决/g, "证据判断")
    .replace(/发布收尾/g, "整理并保存结果")
    .replace(/修订预算/g, "修改次数")
    .replace(/修订/g, "修改")
    .replace(/门禁/g, "检查")
    .replace(/fail closed/gi, "未通过就不发布");
}

function artifactLabel(value: string | undefined): string {
  return value ? ARTIFACT_LABELS[value] ?? readableAuditText(value) : "—";
}

function issueTypeLabel(value: string): string {
  switch (value) {
    case "no_evidence": return "缺少依据";
    case "conflict": return "内容矛盾";
    case "out_of_scope_causality": return "因果越界";
    case "difficulty_mismatch": return "难度不合适";
    case "counterevidence_request": return "需要反证";
    default: return readableAuditText(value);
  }
}

function producerLabel(value: string): string {
  return value === "agent" ? "模型生成" : value === "rule" ? "规则检查" : readableAuditText(value);
}

function timeText(value: number | null | undefined): string {
  if (!value) return "—";
  return new Intl.DateTimeFormat("zh-CN", { month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit" }).format(value);
}

function elapsedText(start: number | null | undefined, end: number | null | undefined): string {
  if (!start) return "尚未开始";
  const seconds = Math.max(0, Math.round(((end ?? Date.now()) - start) / 1000));
  if (seconds < 60) return `${seconds} 秒`;
  const minutes = Math.floor(seconds / 60);
  return seconds % 60 ? `${minutes} 分 ${seconds % 60} 秒` : `${minutes} 分`;
}

type ValidationWorkbenchProps = {
  apiBase: string;
  user: AuthenticatedUser;
  onLogout: () => void;
  onNavigate: (view: "path" | "study" | "resources" | "validation") => void;
  onUserChange?: (user: AuthenticatedUser) => void;
};

export function ValidationWorkbench({ apiBase, user, onLogout, onNavigate, onUserChange }: ValidationWorkbenchProps) {
  const [runs, setRuns] = useState<RunSummary[]>([]);
  const [selectedRunId, setSelectedRunId] = useState<string | null>(null);
  const [trace, setTrace] = useState<TraceData | null>(null);
  const [verify, setVerify] = useState<VerifyResult | null>(null);
  const [verifying, setVerifying] = useState(false);
  const [loading, setLoading] = useState(true);
  const [notice, setNotice] = useState("");
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [profileOpen, setProfileOpen] = useState(false);
  const [processExpanded, setProcessExpanded] = useState(false);
  const [claimsExpanded, setClaimsExpanded] = useState(false);

  const loadRuns = useCallback(async () => {
    const response = await fetch(`${apiBase}/api/learning/runs`, { credentials: "include" });
    const data = await response.json() as { runs?: RunSummary[] };
    const list = data.runs ?? [];
    setRuns(list);
    setLoading(false);
    // 预填：学习页/资源页“查看验证记录”带入 runId
    try {
      const raw = window.localStorage.getItem("im-training-agent:validation-prefill");
      if (raw) {
        window.localStorage.removeItem("im-training-agent:validation-prefill");
        const parsed = JSON.parse(raw) as { runId?: unknown };
        if (typeof parsed.runId === "string" && list.some((run) => run.id === parsed.runId)) {
          setSelectedRunId(parsed.runId);
          return;
        }
      }
    } catch { /* 预填损坏忽略 */ }
    setSelectedRunId((current) => current ?? list[0]?.id ?? null);
  }, [apiBase]);

  useEffect(() => {
    let active = true;
    void fetch(`${apiBase}/api/learning/runs`, { credentials: "include" })
      .then(async (response) => {
        const data = await response.json() as { runs?: RunSummary[] };
        if (!response.ok) throw new Error("任务记录读取失败");
        if (!active) return;
        const list = data.runs ?? [];
        setRuns(list);
        try {
          const raw = window.localStorage.getItem("im-training-agent:validation-prefill");
          if (raw) {
            window.localStorage.removeItem("im-training-agent:validation-prefill");
            const parsed = JSON.parse(raw) as { runId?: unknown };
            if (typeof parsed.runId === "string" && list.some((run) => run.id === parsed.runId)) {
              setSelectedRunId(parsed.runId);
              return;
            }
          }
        } catch { /* 预填损坏忽略 */ }
        setSelectedRunId((current) => current ?? list[0]?.id ?? null);
      })
      .catch((error) => { if (active) setNotice(error instanceof Error ? error.message : "任务记录读取失败"); })
      .finally(() => { if (active) setLoading(false); });
    return () => { active = false; };
  }, [apiBase]);
  useEffect(() => {
    if (!selectedRunId) return;
    let active = true;
    void fetch(`${apiBase}/api/learning/runs/${encodeURIComponent(selectedRunId)}/trace`, { credentials: "include" })
      .then(async (response) => {
        if (!response.ok) throw new Error("验证记录读取失败：该运行可能尚无产物链");
        const data = await response.json() as TraceData;
        if (!active) return;
        setNotice("");
        setTrace(data);
        setVerify(null);
      })
      .catch((error) => { if (active) { setTrace(null); setVerify(null); setNotice(error instanceof Error ? error.message : "验证记录读取失败"); } });
    return () => { active = false; };
  }, [apiBase, selectedRunId]);

  const runVerify = async () => {
    if (!selectedRunId) return;
    setVerifying(true);
    try {
      const response = await fetch(`${apiBase}/api/learning/runs/${encodeURIComponent(selectedRunId)}/verify`, { method: "POST", credentials: "include" });
      const data = await response.json() as VerifyResult & { success?: boolean };
      if (!response.ok || !data.integrity) throw new Error("离线校验失败");
      setVerify(data);
    } catch (error) {
      setNotice(error instanceof Error ? error.message : "离线校验失败");
    } finally {
      setVerifying(false);
    }
  };

  const logout = async () => { await fetch(`${apiBase}/api/auth/logout`, { method: "POST", credentials: "include" }).catch(() => undefined); onLogout(); };

  const auditableClaims = trace?.claimTrace.filter((entry) => entry.auditable) ?? [];
  const unsupportedFinal = auditableClaims.filter((entry) => entry.finalVerdict === "unsupported").length;
  const evidenceCount = new Set(trace?.claimGraph.flatMap((claim) => claim.evidence.map((edge) => edge.evidenceId)) ?? []).size;
  const conflictClaims = trace?.claimGraph.filter((claim) => claim.verdict === "review").length ?? 0;
  const revisionCount = trace?.auditDecisions.length ?? 0;
  const released = trace?.auditDecisions.at(-1)?.released === true;
  const attempts = [...new Set(trace?.claimGraph.map((claim) => claim.attempt ?? 1))].sort((a, b) => a - b);
  const published = Boolean(trace?.run.finalAssetId);

  return <main className="app-shell flex h-screen min-h-0 flex-col overflow-hidden bg-background">
    <WorkspaceHeader user={user} activeView="validation" onNavigate={onNavigate} onSettings={() => setSettingsOpen(true)} onProfile={() => setProfileOpen(true)} onLogout={logout} />

    <div className="min-h-0 flex-1 overflow-y-auto">
      <div className="validation-content mx-auto max-w-5xl space-y-6 px-5 py-6 sm:px-7">

        {/* 1. 任务选择区 */}
        <section aria-label="运行选择" className="validation-panel rounded-xl border bg-card p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2"><ListChecks className="h-4 w-4" /><h2 className="text-sm font-semibold">最近任务</h2></div>
            <button type="button" onClick={() => void loadRuns()} className="validation-ghost-action inline-flex items-center gap-1 px-2 py-1 text-[11px]"><RefreshCw className="h-3 w-3" />刷新</button>
          </div>
          {loading ? <p className="mt-3 text-xs text-muted-foreground">正在读取运行历史…</p> : runs.length === 0
            ? <p className="mt-3 text-xs leading-5 text-muted-foreground">还没有任务记录，到「学习」页开始一次任务后可在这里查看检查结果。</p>
            : <div className="mt-3 grid gap-2 sm:grid-cols-2">
                {runs.map((run) => {
                  const display = runDisplayState(run);
                  return <button key={run.id} type="button" onClick={() => setSelectedRunId(run.id)}
                    className={`validation-task rounded-lg border p-3 text-left transition-colors ${selectedRunId === run.id ? "border-blue-300 bg-blue-50/70" : ""}`}>
                    <div className="flex items-center justify-between gap-2">
                      <span className="text-[11px] font-medium">{RESOURCE_LABELS[run.resourceType] ?? run.resourceType}</span>
                      <span className={`rounded-full px-2 py-0.5 text-[10px] ${display.tone}`}>{display.status}</span>
                    </div>
                    <p className="mt-1.5 line-clamp-2 text-xs leading-4">{run.task || "（无任务描述）"}</p>
                    <p className="mt-1.5 text-[10px] text-muted-foreground">{timeText(run.createdAt)} · {display.publication}</p>
                  </button>;
                })}
              </div>}
        </section>

        {notice && <div className="rounded-lg border border-destructive/25 bg-destructive/5 px-3 py-2 text-xs text-destructive">{notice}</div>}

        {trace && <>
          {/* 2. 可信摘要 */}
          <section aria-label="可信摘要" className="validation-panel rounded-xl border bg-card p-4">
             <div className="flex items-center gap-2"><ShieldCheck className="h-4 w-4" /><h2 className="text-sm font-semibold">可信摘要</h2></div>
            <div className="mt-3 grid grid-cols-2 gap-2 text-center sm:grid-cols-6">
              <Metric label="证据条数" value={evidenceCount} />
              <Metric label="可核对内容" value={auditableClaims.length} />
              <Metric label="最终稿缺少依据" value={unsupportedFinal} tone={unsupportedFinal > 0 ? "warn" : "ok"} />
              <Metric label="需更多依据" value={conflictClaims} />
              <Metric label="修改次数" value={revisionCount} />
              <Metric label="发布结论" value={released ? "已放行" : published ? "异常" : "未放行"} tone={released ? "ok" : "warn"} />
            </div>
             {trace.verificationPolicy ? <div className="mt-3 flex flex-wrap gap-2 text-[11px] text-muted-foreground">
               <span className="rounded-full border bg-background px-2.5 py-1">证据覆盖：{coverageLabel(trace.verificationPolicy.coverageStatus)}</span>
               <span className="rounded-full border bg-background px-2.5 py-1">校验强度：{strengthLabel(trace.verificationPolicy.strength)}</span>
               {trace.verificationPolicy.reasons?.length ? <span className="rounded-full border bg-background px-2.5 py-1">附加约束 {trace.verificationPolicy.reasons.length} 项</span> : null}
             </div> : null}
             <div className="mt-3 flex flex-wrap gap-2 text-[11px] text-muted-foreground">
               <span className="rounded-full border bg-background px-2.5 py-1">等待执行：{trace.run.startedAt ? elapsedText(trace.run.createdAt, trace.run.startedAt) : "尚未开始"}</span>
               <span className="rounded-full border bg-background px-2.5 py-1">实际处理：{elapsedText(trace.run.startedAt, trace.run.finishedAt)}</span>
             </div>
          </section>

          {/* 3. 处理过程 */}
          <section aria-label="处理过程" className="overflow-hidden rounded-2xl border bg-card">
            <div>
              <button type="button" aria-expanded={processExpanded} onClick={() => setProcessExpanded((expanded) => !expanded)} className="group flex w-full items-center justify-between gap-3 px-5 py-4 text-left text-sm hover:bg-blue-50/45">
                <span className="flex items-center gap-2"><Link2 className="h-4 w-4 text-muted-foreground" /><h2 className="font-semibold">处理过程</h2></span>
                <span className="flex items-center gap-2 text-[11px] text-muted-foreground">{trace.nodes.length} 项 <ChevronDown className={`h-4 w-4 transition-transform ${processExpanded ? "rotate-180" : ""}`} /></span>
              </button>
              {processExpanded && <div className="border-t px-5 pb-5 pt-3">
                <div className="space-y-2">
              {trace.nodes.map((node) => {
                const artifact = trace.artifacts.find((item) => item.nodeKey === node.nodeKey && item.attempt === node.attempt && ["learner_snapshot", "evidence_set", "domain_brief", "resource_draft", "claim_audit", "challenge_set", "adjudication", "privacy_decision", "publication_decision"].includes(item.artifactType));
                return <details key={`${node.nodeKey}-${node.attempt}`} className="rounded-xl border bg-background px-3.5 py-3">
                  <summary className="flex cursor-pointer list-none items-center justify-between gap-2 text-xs">
                    <span className="flex items-center gap-2">
                      <span className={`h-2 w-2 rounded-full ${node.status === "succeeded" ? "bg-emerald-600" : node.status === "failed" ? "bg-destructive" : "bg-zinc-300"}`} />
                      <span className="font-medium">{NODE_LABELS[node.nodeKey] ?? node.nodeKey}</span>
                      {node.attempt > 1 ? <span className="rounded-full bg-amber-100 px-1.5 text-[10px] text-amber-700">第 {node.attempt} 轮</span> : null}
                      {node.mandatory ? <span className="rounded-full border px-1.5 text-[10px] text-muted-foreground">必做检查</span> : null}
                    </span>
                    <span className="text-[10px] text-muted-foreground">{ACTOR_LABELS[artifact?.actorKey ?? ""] ?? "—"}{artifact ? ` · ${artifactLabel(artifact.artifactType)}` : ""}</span>
                  </summary>
                  <div className="mt-2.5 space-y-2 border-t pt-2.5 text-[11px] leading-4">
                    {artifact ? <>
                      <p><span className="text-muted-foreground">对外结论：</span>{readableAuditText(artifact.publicRationale.decision)}</p>
                      {artifact.publicRationale.observations.length > 0 ? <p><span className="text-muted-foreground">处理说明：</span>{artifact.publicRationale.observations.map(readableAuditText).join("；")}</p> : null}
                      <p><span className="text-muted-foreground">参考内容：</span>{artifact.inputRefs.length > 0 ? artifact.inputRefs.length + " 个前置结果" : "画像与检索结果"}</p>
                      <p className="break-all"><span className="text-muted-foreground">完整性校验码：</span><code className="text-[10px]">{artifact.contentHash.slice(0, 32)}…</code></p>
                      <p><span className="text-muted-foreground">处理方式：</span>{producerLabel(artifact.producer.kind)}{artifact.producer.kind === "agent" && artifact.producer.model ? `（${artifact.producer.model}）` : ""}</p>
                      {artifact.publicRationale.uncertainty.length > 0 ? <p className="text-amber-700"><span className="text-muted-foreground">需要留意：</span>{artifact.publicRationale.uncertainty.map(readableAuditText).join("；")}</p> : null}
                    </> : <p className="text-muted-foreground">{node.resultSummary ?? "暂无主产物"}</p>}
                    <p><span className="text-muted-foreground">步骤耗时：</span>{elapsedText(node.startedAt, node.finishedAt)}</p>
                  </div>
                </details>;
              })}
                </div>
              </div>}
            </div>
          </section>

          {/* 4. 声明证据表 */}
          <section aria-label="声明证据表" className="overflow-hidden rounded-2xl border bg-card">
            <div>
              <button type="button" aria-expanded={claimsExpanded} onClick={() => setClaimsExpanded((expanded) => !expanded)} className="group flex w-full items-center justify-between gap-3 px-5 py-4 text-left text-sm hover:bg-blue-50/45">
                <span className="flex items-center gap-2"><Table2 className="h-4 w-4 text-muted-foreground" /><h2 className="font-semibold">内容与依据</h2></span>
                <span className="flex items-center gap-2 text-[11px] text-muted-foreground">{trace.claimTrace.length} 条 <ChevronDown className={`h-4 w-4 transition-transform ${claimsExpanded ? "rotate-180" : ""}`} /></span>
              </button>
              {claimsExpanded && <div className="border-t px-5 pb-5 pt-3">
              {trace.claimTrace.length === 0 ? <p className="text-xs text-muted-foreground">该运行没有可核对的声明。</p> : (
              <div className="overflow-x-auto">
                <table className="w-full min-w-[640px] text-left text-[11px]">
                  <thead><tr className="border-b text-muted-foreground"><th className="py-2 pr-3 font-medium">内容</th><th className="py-2 pr-3 font-medium">类型</th><th className="py-2 pr-3 font-medium">处理轮次</th><th className="py-2 pr-3 font-medium">最终结论</th><th className="py-2 pr-3 font-medium">依据</th><th className="py-2 font-medium">待处理问题</th></tr></thead>
                  <tbody>
                    {trace.claimTrace.map((entry) => {
                      const finalStage = entry.stages.at(-1);
                      return <tr key={entry.logicalKey ?? entry.stages[0]?.claimId} className="border-b last:border-0 align-top">
                        <td className="max-w-[240px] py-2 pr-3 leading-4">{readableAuditText(entry.stages[0]?.text.slice(0, 80) ?? "")}{entry.stages.length > 1 ? <span className="ml-1 text-[10px] text-muted-foreground">（修改 {entry.stages.length - 1} 次）</span> : null}</td>
                        <td className="py-2 pr-3">{claimTypeLabel(entry.claimType)}</td>
                        <td className="py-2 pr-3">{entry.stages.map((stage) => stage.attempt).join("→")}</td>
                        <td className="py-2 pr-3"><span className={`rounded-full px-2 py-0.5 text-[10px] ${finalStage?.verdict === "supported" ? "bg-emerald-100 text-emerald-700" : finalStage?.verdict === "unsupported" ? "bg-destructive/10 text-destructive" : "bg-amber-100 text-amber-700"}`}>{verdictLabel(finalStage?.verdict)}</span></td>
                        <td className="py-2 pr-3">{finalStage?.evidence.length ? `${finalStage.evidence.length} 条` : entry.auditable ? "无" : "不适用"}</td>
                        <td className="py-2">{entry.issues.length ? `${entry.issues.length} 条（${entry.issues.map((issue) => issueTypeLabel(issue.issueType)).join("、")}）` : "—"}</td>
                      </tr>;
                    })}
                  </tbody>
                </table>
              </div>
            )}
              </div>}
            </div>
          </section>

          {/* 5. 前后对照 */}
          <section aria-label="前后对照" className="validation-panel rounded-xl border bg-card p-4">
            <div className="flex items-start gap-2"><BadgeCheck className="mt-0.5 h-4 w-4" /><h2 className="text-sm font-semibold">前后对照</h2></div>
             {attempts.length <= 1
               ? <div className="mt-3 grid grid-cols-2 gap-2 sm:grid-cols-4">
                   <Metric label="处理轮次" value={attempts.length || "—"} />
                   <Metric label="开始时记录" value={trace.snapshots.runStart ? "已记录" : "—"} tone={trace.snapshots.runStart ? "ok" : undefined} />
                   <Metric label="结束时记录" value={trace.snapshots.generationEnd ? "已记录" : "—"} tone={trace.snapshots.generationEnd ? "ok" : undefined} />
                   <Metric label="是否可比较" value={trace.snapshots.runStart && trace.snapshots.generationEnd ? "可以" : "部分"} tone={trace.snapshots.runStart && trace.snapshots.generationEnd ? "ok" : "warn"} />
                 </div>
               : <div className="mt-3 space-y-2">
                  {attempts.map((attempt) => {
                    const stageClaims = trace.claimGraph.filter((claim) => (claim.attempt ?? 1) === attempt);
                    const unsupported = stageClaims.filter((claim) => claim.verdict === "unsupported").length;
                    const decision = trace.auditDecisions.find((item) => item.round === attempt);
                    return <div key={attempt} className="rounded-lg border bg-background px-3.5 py-3 text-[11px]">
                      <div className="flex items-center justify-between"><span className="font-medium">第 {attempt} 轮</span><span>{decision ? `检查结果：${verdictLabel(decision.verdict)}${decision.released ? "（已通过）" : ""}` : "暂无检查结果"}</span></div>
                      <p className="mt-1 text-muted-foreground">可核对内容 {stageClaims.filter((claim) => claim.claimType !== "non_factual").length} 条、缺少依据 {unsupported} 条</p>
                    </div>;
                  })}
                </div>}
          </section>

          {/* 6. 记录完整性检查 */}
          <section aria-label="记录完整性检查" className="validation-panel rounded-xl border bg-card p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-start gap-2"><ScrollText className="mt-0.5 h-4 w-4" /><h2 className="text-sm font-semibold">记录完整性检查</h2></div>
              <button type="button" onClick={() => void runVerify()} disabled={verifying} className="validation-record-action validation-record-action-quiet inline-flex h-8 items-center gap-1.5 px-2.5 text-[11px] font-medium disabled:opacity-50"><RefreshCw className={`h-3.5 w-3.5 ${verifying ? "animate-spin" : ""}`} />{verifying ? "检查中" : "重新检查"}</button>
            </div>
            {verify ? <div className="mt-3 space-y-1.5 text-[11px]">
              {verify.integrity.checks.map((check) => <div key={check.id} className="flex items-start gap-2"><span className={check.passed ? "text-emerald-600" : "text-destructive"}>{check.passed ? "✔" : "✘"}</span><span><span className="font-medium">{readableAuditText(check.label)}</span><span className="text-muted-foreground">：{readableAuditText(check.detail)}</span></span></div>)}
              {verify.replay.attempts.map((attempt) => <div key={attempt.attempt} className="text-muted-foreground">第 {attempt.attempt} 轮检查结果：{verdictLabel(attempt.ruleGate)}，已记录结论：{verdictLabel(attempt.recordedVerdict ?? undefined)} → {attempt.match ? "一致" : "✘ 不一致"}</div>)}
              {verify.replay.differences.length > 0 ? <p className="text-destructive">{verify.replay.differences.map(readableAuditText).join("；")}</p> : null}
            </div> : <p className="mt-3 text-xs text-muted-foreground">检查本次任务的内容、引用、修改记录和发布结论是否一致。</p>}
          </section>

          {/* 7. 记录操作 */}
          <section aria-label="记录操作" className="validation-record-actions">
             <div className="flex min-w-0 items-center gap-2"><FileJson className="h-4 w-4 shrink-0" /><div className="min-w-0"><h2 className="text-sm font-semibold">记录操作</h2><p className="mt-0.5 text-[11px] text-muted-foreground">保留本次任务的可追溯结果</p></div></div>
            <div className="flex shrink-0 items-center gap-1.5">
              <button type="button" onClick={() => window.open(`${apiBase}/api/learning/runs/${encodeURIComponent(trace.run.id)}/export`, "_blank", "noopener,noreferrer")} className="validation-record-action inline-flex h-8 items-center gap-1.5 px-2.5 text-[11px] font-medium"><Download className="h-3.5 w-3.5" />下载</button>
              {published ? <button type="button" onClick={() => onNavigate("resources")} className="validation-record-action validation-record-action-quiet inline-flex h-8 items-center gap-1 px-2 text-[11px]"><span>查看资源</span><ArrowRight className="h-3.5 w-3.5" /></button> : null}
            </div>
          </section>
        </>}
      </div>
    </div>
    {settingsOpen && <SettingsDialog apiBase={apiBase} onClose={() => setSettingsOpen(false)} />}
    {profileOpen && <ProfileDialog apiBase={apiBase} user={user} onUserChange={onUserChange} onClose={() => setProfileOpen(false)} />}
  </main>;
}

function Metric({ label, value, tone }: { label: string; value: string | number; tone?: "ok" | "warn" }) {
  return <div className={`rounded-lg p-2.5 ${tone === "warn" ? "bg-amber-50" : tone === "ok" ? "bg-emerald-50" : "bg-muted/60"}`}>
    <div className="text-[10px] text-muted-foreground">{label}</div>
    <div className={`mt-1 text-sm font-semibold ${tone === "warn" ? "text-amber-700" : tone === "ok" ? "text-emerald-700" : ""}`}>{value}</div>
  </div>;
}

function coverageLabel(value: string | undefined): string {
  return value === "rich" ? "充分" : value === "sparse" ? "偏少" : value === "normal" ? "正常" : "—";
}

function strengthLabel(value: string | undefined): string {
  return value === "strict" ? "从严" : value === "standard" ? "标准" : "—";
}

function claimTypeLabel(claimType: string | null): string {
  switch (claimType) {
    case "numeric": return "数值";
    case "field_meaning": return "字段含义";
    case "method_step": return "方法步骤";
    case "causal": return "因果判断";
    case "risk_advice": return "风险建议";
    case "non_factual": return "非事实表达";
    default: return "事实声明";
  }
}

function verdictLabel(verdict: string | undefined): string {
  switch (verdict) {
    case "supported": return "支持";
    case "review": return "需更多依据";
    case "partial": return "部分支持";
    case "conflict": return "冲突";
    case "unsupported": return "无证据";
    default: return "—";
  }
}
