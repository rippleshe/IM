import { describe, expect, it } from 'vitest';
import { auditResource } from './audit.js';
import {
  buildLlmResourceDocument,
  buildResourceDraft,
  parseLlmResourceDraft,
} from './resource-builder.js';
import type { EvidenceItem, EvidencePack, LearningResourceType, QuizQuestion } from './types.js';

function evidenceItem(id: string, content: string, sourceType: EvidenceItem['sourceType'] = 'dataset'): EvidenceItem {
  return {
    id,
    sourceType,
    sourceId: 'ai4i-2020',
    sourceTitle: 'AI4I 测试数据',
    locator: 'row 42',
    content,
    retrievalMethod: 'sql',
    relevanceScore: 0.9,
    trustLevel: 'high',
  };
}

function pack(items: EvidenceItem[]): EvidencePack {
  return {
    id: 'pack-1',
    query: '设备数据观察',
    items,
    retrievalPlan: ['structured'],
    coverageScore: 0.9,
    crossValidation: { status: 'corroborated', score: 1, checks: [], notes: [] },
    structuredCount: items.length,
    documentCount: 0,
    temporaryCount: 0,
    privacy: { temporaryReferenceUsed: false, retained: false },
    createdAt: 0,
  };
}

const EVIDENCE = [
  evidenceItem('e1', 'Air temperature [K] = 298.1, Torque [Nm] = 52.3, Machine failure = 0'),
  evidenceItem('e2', '故障样本 33 条，正常样本 9967 行，失败率约 0.33%', 'document'),
  // 行级结构化证据：讲义“数据摘录”表格的来源（representativeTable 只认 recent_rows/dataset_row）
  evidenceItem('e3', JSON.stringify({ 'Machine failure': 1, 'Air temperature [K]': 298.1, 'Torque [Nm]': 52.3, 'Tool wear [min]': 0 }), 'dataset'),
];

EVIDENCE[2]!.metadata = { queryKind: 'recent_rows' };

describe('parseLlmResourceDraft：结构校验与回退', () => {
  it('讲义：完整输出解析为各字段，缺失字段被剔除', () => {
    const draft = parseLlmResourceDraft('lecture', {
      title: '观察设备数据',
      lead: '这份讲义带你从字段开始。',
      objectives: ['说出字段含义'],
      sections: [
        { heading: '从一行数据开始', text: '正文 300 字……', code: { language: 'python', code: 'import pandas as pd' }, keyPoints: ['记住字段名'] },
        { heading: '故障样本', text: '正文……' },
      ],
      misconceptions: [{ wrong: '异常即故障', correct: '异常只是风险信号' }],
      reviewQuestions: ['你会先看哪个字段？'],
    });
    expect(draft).not.toBeNull();
    expect(draft?.kind).toBe('lecture');
    if (draft?.kind !== 'lecture') return;
    expect(draft.sections).toHaveLength(2);
    expect(draft.sections[0]?.code?.code).toContain('pandas');
    expect(draft.misconceptions).toHaveLength(1);
    expect(draft.reviewQuestions).toHaveLength(1);
  });

  it('讲义：缺标题或小节不足 2 → 返回 null（模板兜底）', () => {
    expect(parseLlmResourceDraft('lecture', { title: 'x', sections: [{ heading: 'a', text: 'b' }] })).toBeNull();
    expect(parseLlmResourceDraft('lecture', { sections: [{ heading: 'a', text: 'b' }, { heading: 'c', text: 'd' }] })).toBeNull();
  });

  it('PPT：空 bullets 的页被过滤，页数不足 → null', () => {
    const draft = parseLlmResourceDraft('presentation', {
      title: '诊断演示',
      slides: [
        { heading: '问题', bullets: ['温度偏高', '扭矩波动'], notes: '讲解词' },
        { heading: '空页', bullets: [] },
        { heading: '行动', bullets: ['现场复核'] },
      ],
    });
    expect(draft?.kind).toBe('presentation');
    if (draft?.kind !== 'presentation') return;
    expect(draft.slides).toHaveLength(2);
    expect(parseLlmResourceDraft('presentation', { title: 'x', slides: [{ heading: 'a', bullets: [] }] })).toBeNull();
  });

  it('习题：非法 level/选项不足被过滤，answerId 非法时回退首个选项', () => {
    const draft = parseLlmResourceDraft('tiered_quiz', {
      title: '分层练习',
      questions: [
        { level: 'L1', prompt: '选项不足', options: [{ id: 'A', text: 'a' }, { id: 'B', text: 'b' }], answerId: 'A', explanation: 'x' },
        { level: 'L9', prompt: '非法层级', options: [{ id: 'A', text: 'a' }, { id: 'B', text: 'b' }, { id: 'C', text: 'c' }], answerId: 'A', explanation: 'x' },
        { level: 'L2', prompt: '有效题', options: [{ id: 'A', text: 'a' }, { id: 'B', text: 'b' }, { id: 'C', text: 'c' }, { id: 'D', text: 'd' }], answerId: 'C', explanation: '因为 C' },
        { level: 'L3', prompt: 'answerId 非法', options: [{ id: 'A', text: 'a' }, { id: 'B', text: 'b' }, { id: 'C', text: 'c' }, { id: 'D', text: 'd' }], answerId: 'E', explanation: 'x' },
      ],
    });
    expect(draft?.kind).toBe('tiered_quiz');
    if (draft?.kind !== 'tiered_quiz') return;
    expect(draft.questions).toHaveLength(2);
    expect(draft.questions[0]?.answerId).toBe('C');
    expect(draft.questions[1]?.answerId).toBe('E'); // 解析层透传，回退在组装层处理
    expect(parseLlmResourceDraft('tiered_quiz', { title: 'x', questions: [] })).toBeNull();
  });

  it('知识脉络：缺 mermaid → null', () => {
    expect(parseLlmResourceDraft('concept_map', { title: 'x', map: { mermaid: '', nodes: [] } })).toBeNull();
  });
});

describe('buildLlmResourceDocument：块组装与证据绑定', () => {
  it('讲义：lead + 各节 + 误区 + 自测 + 数据表 + 证据卡，内容块全部绑定证据', () => {
    const llm = parseLlmResourceDraft('lecture', {
      title: '观察设备数据',
      lead: '导语',
      objectives: ['识别关键字段'],
      sections: [
        { heading: '从一行数据开始', text: 'Air temperature [K] 为 298.1，先用肉眼观察。' },
        { heading: '故障样本', text: '证据中故障样本 33 条。', code: { caption: '读取故障样本', language: 'python', code: 'df[df["Machine failure"] == 1]' } },
      ],
    })!;
    const doc = buildLlmResourceDocument('task-1', '设备数据观察', 'lecture', pack(EVIDENCE), 'industrial-diagnosis-foundation', llm);
    const types = doc.blocks.map((block) => block.type);
    expect(types[0]).toBe('paragraph'); // lead
    expect(types).toContain('heading');
    expect(types).toContain('code');
    expect(types).toContain('table'); // representativeTable 由 row 证据生成
    // LLM 已提供 code → 不再附加内置 pandas 示例
    expect(doc.blocks.filter((block) => block.type === 'code')).toHaveLength(1);
    // 除代码/表格外，内容块都绑定证据供 Claim 审核回溯
    for (const block of doc.blocks) {
      if (['code', 'table', 'evidence'].includes(block.type)) continue;
      if (block.type === 'paragraph' && String(block.content).startsWith('flowchart')) continue;
      expect(block.evidenceIds.length).toBeGreaterThan(0);
    }
  });

  it('PPT：每页为 heading + 要点列表 + 讲解词段落', () => {
    const llm = parseLlmResourceDraft('presentation', {
      title: '诊断演示',
      slides: [
        { heading: '问题', bullets: ['温度偏高', '扭矩波动'], notes: '这一页说明现象。' },
        { heading: '行动', bullets: ['现场复核'] },
      ],
    })!;
    const doc = buildLlmResourceDocument('task-1', '压缩机诊断', 'presentation', pack(EVIDENCE), 'kp', llm);
    const headings = doc.blocks.filter((block) => block.type === 'heading');
    expect(headings).toHaveLength(2);
    const lists = doc.blocks.filter((block) => block.type === 'list');
    expect(lists).toHaveLength(2);
    expect(doc.blocks.some((block) => block.type === 'paragraph' && String(block.content).includes('这一页说明现象'))).toBe(true);
  });

  it('习题：生成 question 块，非法 answerId 回退首个选项', () => {
    const llm = parseLlmResourceDraft('tiered_quiz', {
      title: '分层练习',
      questions: [
        { level: 'L1', prompt: '题干一', options: [{ id: 'A', text: 'a' }, { id: 'B', text: 'b' }, { id: 'C', text: 'c' }, { id: 'D', text: 'd' }], answerId: 'B', explanation: 'B 对' },
        { level: 'L2', prompt: '题干二', options: [{ id: 'A', text: 'a' }, { id: 'B', text: 'b' }, { id: 'C', text: 'c' }, { id: 'D', text: 'd' }], answerId: 'E', explanation: '' },
      ],
    })!;
    const doc = buildLlmResourceDocument('task-1', '证据边界', 'tiered_quiz', pack(EVIDENCE), 'kp', llm);
    const questionBlock = doc.blocks.find((block) => block.type === 'question');
    expect(questionBlock).toBeDefined();
    const questions = (questionBlock!.content as { questions: Array<{ answerId: string; explanation: string }> }).questions;
    expect(questions).toHaveLength(2);
    expect(questions[1]!.answerId).toBe('A'); // 非法 answerId → 回退第一个选项
    expect(questions[1]!.explanation.length).toBeGreaterThan(0);
  });

  it('知识脉络：mermaid 非法 → 回退确定性模板', () => {
    const llm = { kind: 'concept_map' as const, title: '知识脉络', objectives: [], map: { mermaid: '不是 mermaid 语法', nodes: [] } };
    const doc = buildLlmResourceDocument('task-1', '压缩机诊断', 'concept_map', pack(EVIDENCE), 'kp', llm);
    // 模板兜底：包含 flowchart 段落与 checklist
    expect(doc.blocks.some((block) => block.type === 'paragraph' && String(block.content).startsWith('flowchart'))).toBe(true);
  });

  it('知识脉络：合法 mermaid + 节点解读 + 阅读路径', () => {
    const llm = {
      kind: 'concept_map' as const,
      title: '证据到判断',
      objectives: ['建立知识关系'],
      map: {
        mermaid: 'flowchart TD\n  A[传感器证据] --> B[风险判断]\n  B --> C[现场复核]',
        nodes: [{ label: '传感器证据', explanation: '来自 AI4I 与 MetroPT-3 的字段观察。' }],
        readingPaths: [{ title: '入门阅读线', steps: ['传感器证据', '风险判断', '现场复核'] }],
      },
    };
    const doc = buildLlmResourceDocument('task-1', '压缩机诊断', 'concept_map', pack(EVIDENCE), 'kp', llm);
    expect(doc.blocks[1]?.type).toBe('paragraph');
    expect(String(doc.blocks[1]?.content)).toMatch(/^flowchart TD/);
    expect(doc.blocks.some((block) => String(block.content).includes('**传感器证据**'))).toBe(true);
    expect(doc.blocks.some((block) => block.type === 'heading' && String(block.content).includes('入门阅读线'))).toBe(true);
  });
});

describe('生成 → 审核门禁联动', () => {
  it('数字与证据一致 → 无 unsupported/review，可过门禁', () => {
    const llm = parseLlmResourceDraft('lecture', {
      title: '观察设备数据',
      objectives: ['识别字段'],
      sections: [
        { heading: '字段观察', text: 'Torque [Nm] 为 52.3，处于正常范围。' },
        { heading: '故障占比', text: '证据中故障样本 33 条，失败率约 0.33%。' },
      ],
    })!;
    const doc = buildLlmResourceDocument('task-1', '设备数据观察', 'lecture', pack(EVIDENCE), 'kp', llm);
    const result = auditResource(doc, pack(EVIDENCE));
    const auditable = result.claims.filter((claim) => claim.claimType !== 'non_factual');
    expect(auditable.length).toBeGreaterThan(0);
    expect(auditable.every((claim) => claim.verdict === 'supported')).toBe(true);
  });

  it('正文引用证据外的数字 → 数值核验降级，门禁能抓住', () => {
    const llm = parseLlmResourceDraft('lecture', {
      title: '观察设备数据',
      objectives: ['识别字段'],
      sections: [
        { heading: '字段观察', text: 'Torque [Nm] 为 999.9，远超正常值。' },
        { heading: '故障占比', text: '证据显示故障样本 33 条。' },
      ],
    })!;
    const doc = buildLlmResourceDocument('task-1', '设备数据观察', 'lecture', pack(EVIDENCE), 'kp', llm);
    const result = auditResource(doc, pack(EVIDENCE));
    expect(result.summary.status).not.toBe('corroborated');
    expect(result.claims.some((claim) => claim.verdict !== 'supported')).toBe(true);
  });

  it('模板兜底（quiz）仍产出可判分的三层三题型题目', () => {
    const doc = buildResourceDraft('task-1', '证据边界', 'tiered_quiz', pack(EVIDENCE), 'kp');
    const questionBlock = doc.blocks.find((block) => block.type === 'question');
    const questions = (questionBlock!.content as { questions: Array<{ level: string; type: string }> }).questions;
    expect(questions).toHaveLength(9);
    expect(questions.map((question) => question.level)).toEqual(['L1', 'L1', 'L1', 'L2', 'L2', 'L2', 'L3', 'L3', 'L3']);
    for (const level of ['L1', 'L2', 'L3']) {
      const levelQuestions = questions.filter((question) => question.level === level);
      expect(levelQuestions.map((question) => question.type).sort()).toEqual(['blank', 'choice', 'short_answer']);
    }
  });

  it('判分：填空多候选规范化匹配，简答按自评', async () => {
    const { judgeQuizAnswer } = await import('./quiz.js');
    const blank: QuizQuestion = { id: 'q', type: 'blank', level: 'L1', prompt: 'p', answerId: '风险|风险判断', explanation: '', evidenceIds: [] };
    expect(judgeQuizAnswer(blank, ' 风险判断 ')).toBe(true);
    expect(judgeQuizAnswer(blank, '故障')).toBe(false);
    const short: QuizQuestion = { id: 'q2', type: 'short_answer', level: 'L2', prompt: 'p', answerId: '要点', explanation: '', evidenceIds: [] };
    expect(judgeQuizAnswer(short, '我的回答', { selfAssessed: true })).toBe(true);
    expect(judgeQuizAnswer(short, '我的回答', { selfAssessed: false })).toBe(false);
    const choice: QuizQuestion = { id: 'q3', level: 'L1', prompt: 'p', options: [{ id: 'A', text: 'a' }], answerId: 'A', explanation: '', evidenceIds: [] };
    expect(judgeQuizAnswer(choice, 'A')).toBe(true);
  });
});
