/**
 * PostgreSQL 版证据检索与数据集查询（docs/挑战杯技术开发总规.md §6.1 第 5/6 组、§7.5）
 *
 * - 结构化证据：PG metro_readings / dataset_rows 精确查询；
 * - 文档证据：to_tsvector('simple') 全文召回，ILIKE 兜底；向量召回在运行时混合检索层接入；
 * - EvidencePack / 隐私审计事件持久化到 PG evidence_* 与 privacy_audit_events；
 * - seedMetroCatalogPg / importKnowledgeCardsPg / importCsvDatasetPg / importMetroPt3CsvPg
 *   供干净环境引导（Compose bootstrap）使用。
 */
import { createReadStream } from 'node:fs';
import { createHash, randomUUID } from 'node:crypto';
import { existsSync, readdirSync, readFileSync } from 'node:fs';
import path from 'node:path';
import { pipeline } from 'node:stream/promises';
import type { Pool, PoolClient } from 'pg';
import { from as copyFrom } from 'pg-copy-streams';

import { crossValidate, normalizeSearchTerms } from '../../src/learning/evidence-rules.js';
import { hybridDocumentRowsPg } from './pg-retrieval.js';
import {
  chooseWebSearchTrigger,
  getSearxngConfig,
  getWebSearchStatus as getSearxngStatus,
  searchSearxng,
} from '../search/searxng.js';
import { persistWebSearchCandidates } from '../knowledge-web.js';
import type {
  CsvDatasetSource,
  DatasetSummary,
  EvidenceItem,
  EvidencePack,
  EvidenceScope,
  MetroReading,
} from '../../src/learning/types.js';

const METRO_DATASET_ID = 'metropt-3';
const KNOWLEDGE_CARD_SOURCE_ID = 'knowledge-cards';

const MAX_CHUNK_CHARS = 1200;
const MIN_CHUNK_CHARS = 160;

function toBlocks(lines: string[]): string[] {
  const blocks: string[] = [];
  let buffer: string[] = [];
  let inFence = false;
  const flush = () => {
    const text = buffer.join('\n').trim();
    if (text) blocks.push(text);
    buffer = [];
  };
  for (const line of lines) {
    if (line.trimStart().startsWith('```')) {
      inFence = !inFence;
      buffer.push(line);
      if (!inFence) flush();
      continue;
    }
    if (!inFence && line.trim() === '') {
      flush();
      continue;
    }
    buffer.push(line);
  }
  flush();
  return blocks;
}

function packBlocks(blocks: string[]): string[] {
  const packed: string[] = [];
  let buffer = '';
  const pushLinePacked = (block: string) => {
    let part = '';
    for (const line of block.split('\n')) {
      const next = part ? `${part}\n${line}` : line;
      if (next.length > MAX_CHUNK_CHARS && part) {
        packed.push(part);
        part = line;
      } else {
        part = next;
      }
    }
    if (part) packed.push(part);
  };
  for (const block of blocks) {
    const candidate = buffer ? `${buffer}\n\n${block}` : block;
    if (candidate.length <= MAX_CHUNK_CHARS) {
      buffer = candidate;
      continue;
    }
    if (buffer) packed.push(buffer);
    if (block.length > MAX_CHUNK_CHARS) {
      pushLinePacked(block);
      buffer = '';
    } else {
      buffer = block;
    }
  }
  if (buffer) packed.push(buffer);
  return packed;
}

function chunkCardContent(content: string): Array<{ heading: string; text: string }> {
  const normalized = content.replace(/\r\n/g, '\n').replace(/\n{3,}/g, '\n\n').trim();
  const sections: Array<{ heading: string; lines: string[] }> = [{ heading: '', lines: [] }];
  for (const line of normalized.split('\n')) {
    const matched = line.match(/^##\s+(.+)$/)?.[1];
    if (matched) sections.push({ heading: matched.trim(), lines: [] });
    else sections[sections.length - 1]?.lines.push(line);
  }
  const chunks: Array<{ heading: string; text: string }> = [];
  for (const section of sections) {
    for (const text of packBlocks(toBlocks(section.lines))) chunks.push({ heading: section.heading, text });
  }
  const merged: Array<{ heading: string; text: string }> = [];
  for (const chunk of chunks) {
    const previous = merged[merged.length - 1];
    if (previous && chunk.text.length < MIN_CHUNK_CHARS) {
      previous.text = `${previous.text}\n\n${chunk.text}`;
      continue;
    }
    merged.push({ heading: chunk.heading, text: chunk.text });
  }
  return merged.filter((chunk) => chunk.text.length >= 40);
}

/* ------------------------------------------------------------------ */
/* 数据集查询（结构化证据）                                               */
/* ------------------------------------------------------------------ */

export async function getMetroSummaryPg(pool: Pool): Promise<DatasetSummary> {
  const row = (await pool.query(
    'SELECT COUNT(*) AS "rowCount", MIN(timestamp) AS "firstTimestamp", MAX(timestamp) AS "lastTimestamp" FROM metro_readings',
  )).rows[0] as { rowCount: string | number; firstTimestamp: string | null; lastTimestamp: string | null };
  const fieldCount = (await pool.query(
    'SELECT COUNT(*) AS count FROM dataset_fields WHERE dataset_id = $1', [METRO_DATASET_ID],
  )).rows[0] as { count: string | number };
  return {
    id: METRO_DATASET_ID,
    name: 'MetroPT-3 Air Compressor',
    rowCount: Number(row.rowCount),
    firstTimestamp: row.firstTimestamp,
    lastTimestamp: row.lastTimestamp,
    fieldCount: Number(fieldCount.count),
  };
}

function metroQueryShape(query: string): { where: string; orderBy: string } {
  const text = query.toLowerCase();
  if (/压力|pressure|tp2|tp3|reservoir|lps|低压/.test(text)) {
    return {
      where: 'tp2 IS NOT NULL OR tp3 IS NOT NULL OR dv_pressure IS NOT NULL OR reservoirs IS NOT NULL',
      orderBy: 'GREATEST(ABS(COALESCE(tp2, 0) - COALESCE(tp3, 0)), ABS(COALESCE(dv_pressure, 0))) DESC NULLS LAST, timestamp DESC',
    };
  }
  if (/油温|温度|temperature|oil_temperature/.test(text)) {
    return { where: 'oil_temperature IS NOT NULL', orderBy: 'oil_temperature DESC NULLS LAST, timestamp DESC' };
  }
  if (/电流|current|motor_current/.test(text)) {
    return { where: 'motor_current IS NOT NULL', orderBy: 'motor_current DESC NULLS LAST, timestamp DESC' };
  }
  if (/阀|valve|dv_pressure|dv_electric|pressure_switch/.test(text)) {
    return { where: 'dv_pressure IS NOT NULL OR dv_electric IS NOT NULL OR pressure_switch IS NOT NULL', orderBy: 'ABS(COALESCE(dv_pressure, 0)) DESC NULLS LAST, timestamp DESC' };
  }
  return { where: 'TRUE', orderBy: 'timestamp DESC' };
}

export async function queryMetroReadingsPg(pool: Pool, limit = 5, query = ''): Promise<MetroReading[]> {
  const boundedLimit = Math.max(1, Math.min(limit, 20));
  const shape = metroQueryShape(query);
  const rows = await pool.query(
    `SELECT row_id AS "rowId", timestamp, tp2, tp3, h1, dv_pressure AS "dvPressure",
      reservoirs, oil_temperature AS "oilTemperature", motor_current AS "motorCurrent",
      comp, dv_electric AS "dvElectric", towers, mpg, lps,
      pressure_switch AS "pressureSwitch", oil_level AS "oilLevel",
      caudal_impulses AS "caudalImpulses"
     FROM metro_readings WHERE ${shape.where} ORDER BY ${shape.orderBy} LIMIT $1`, [boundedLimit],
  );
  return rows.rows as MetroReading[];
}

export async function getDatasetRowCountPg(pool: Pool, datasetId: string): Promise<number> {
  const row = (await pool.query('SELECT COUNT(*) AS count FROM dataset_rows WHERE dataset_id = $1', [datasetId])).rows[0] as { count: string | number };
  return Number(row.count);
}

export interface DatasetRowSample {
  rowId: number;
  fields: Record<string, string | number | null>;
}

/** 代表性样本：优先取标签字段命中的故障行（教学上最有展示价值），再补正常行。 */
export async function sampleDatasetRowsPg(pool: Pool, datasetId: string, limit = 3): Promise<DatasetRowSample[]> {
  const labelFields = ((await pool.query(
    `SELECT field_name AS "fieldName" FROM dataset_fields
     WHERE dataset_id = $1 AND label_role = 'label' ORDER BY field_name`, [datasetId],
  )).rows as Array<{ fieldName: string }>).map((row) => row.fieldName);
  const positives: DatasetRowSample[] = [];
  for (const field of labelFields) {
    if (positives.length >= limit) break;
    const needed = limit - positives.length;
    const known = new Set(positives.map((row) => row.rowId));
    const candidates = (await pool.query(
      `SELECT row_id AS "rowId", data_json AS "dataJson" FROM dataset_rows
       WHERE dataset_id = $1 AND data_json ->> $2 = '1'
       ORDER BY row_id LIMIT $3`, [datasetId, field, needed * 4],
    )).rows as Array<{ rowId: number; dataJson: Record<string, string | number | null> }>;
    for (const candidate of candidates) {
      if (positives.length >= limit || known.has(candidate.rowId)) continue;
      if (labelFields.some((label) => candidate.dataJson[label] === 1 || candidate.dataJson[label] === '1')) {
        positives.push({ rowId: Number(candidate.rowId), fields: candidate.dataJson });
        known.add(candidate.rowId);
      }
    }
  }
  if (positives.length < limit) {
    const known = new Set(positives.map((row) => row.rowId));
    const fallback = (await pool.query(
      `SELECT row_id AS "rowId", data_json AS "dataJson" FROM dataset_rows
       WHERE dataset_id = $1 AND row_id % 997 = 1 LIMIT $2`, [datasetId, limit],
    )).rows as Array<{ rowId: number; dataJson: Record<string, string | number | null> }>;
    for (const row of fallback) {
      if (positives.length >= limit || known.has(row.rowId)) continue;
      positives.push({ rowId: Number(row.rowId), fields: row.dataJson });
      known.add(row.rowId);
    }
  }
  return positives.slice(0, limit).sort((a, b) => a.rowId - b.rowId);
}

/* ------------------------------------------------------------------ */
/* 文档检索（全文）                                                      */
/* ------------------------------------------------------------------ */

function toTsQuery(terms: string[]): string | null {
  const cleaned = terms
    .map((term) => term.replaceAll(/[^\p{L}\p{N} ]/gu, ' ').trim().replace(/\s+/g, ' '))
    .filter((term) => term.length > 0)
    .map((term) => `'${term.replaceAll("'", '')}'`);
  if (cleaned.length === 0) return null;
  return cleaned.join(' | ');
}

/* ------------------------------------------------------------------ */
/* 证据装配                                                             */
/* ------------------------------------------------------------------ */

function evidenceItem(item: Omit<EvidenceItem, 'id'>): EvidenceItem {
  return { id: `evidence-${randomUUID()}`, ...item };
}

function structuredIntent(query: string, terms: string[]): { text: string; wantsRows: boolean; wantsDatasets: boolean; metroRelevant: boolean } | null {
  const text = `${query} ${terms.join(' ')}`.toLowerCase();
  if (!/数据|dataset|csv|字段|field|feature|传感器|sensor|压力|pressure|油温|温度|temperature|电流|current|阀|valve|低压|lps|故障|failure|fault|异常|anomaly|时序|time series|样本|sample|数据行|row|观测|reading/.test(text)) return null;
  const ai4iOnly = /ai4i/.test(text) && !/metropt|压缩机/.test(text);
  return {
    text,
    wantsRows: /数据|dataset|csv|传感器|sensor|压力|pressure|油温|温度|temperature|电流|current|阀|valve|低压|lps|故障|failure|fault|异常|anomaly|时序|time series|样本|sample|数据行|row|观测|reading/.test(text),
    wantsDatasets: /数据集|dataset|csv|ai4i|metropt|样本|sample|数据行|row/.test(text),
    metroRelevant: !ai4iOnly && /metropt|压缩机|传感器|sensor|压力|pressure|油温|温度|temperature|电流|current|阀|valve|低压|lps|故障|failure|fault|异常|anomaly|时序|time series|字段|field|feature|reading|观测/.test(text),
  };
}

async function datasetFieldEvidencePg(pool: Pool, terms: string[]): Promise<EvidenceItem[]> {
  const patterns = [...new Set(terms.filter((term) => term.length >= 2))].slice(0, 10);
  if (patterns.length === 0) return [];
  const wantsFieldCatalog = terms.some((term) => ['字段', 'field', 'feature', 'attribute'].includes(term));
  const clauses = patterns.map((_, index) => {
    const parameter = `$${index + 2}`;
    return `(LOWER(COALESCE(field_name, '')) LIKE ${parameter} OR LOWER(COALESCE(meaning, '')) LIKE ${parameter} OR LOWER(COALESCE(unit, '')) LIKE ${parameter} OR LOWER(COALESCE(label_role, '')) LIKE ${parameter})`;
  }).join(' OR ');
  const rows = (await pool.query(
    `SELECT dataset_id AS "datasetId", field_name AS "fieldName", data_type AS "dataType", meaning, unit, label_role AS "labelRole"
     FROM dataset_fields WHERE dataset_id = $1 AND (${wantsFieldCatalog ? 'TRUE' : clauses})
     ORDER BY field_name LIMIT 8`,
    wantsFieldCatalog ? [METRO_DATASET_ID] : [METRO_DATASET_ID, ...patterns.map((term) => `%${term}%`)],
  )).rows as Array<{ datasetId: string; fieldName: string; dataType: string; meaning: string | null; unit: string | null; labelRole: string | null }>;
  return rows.map((row, index) => evidenceItem({
    sourceType: 'dataset',
    sourceId: row.datasetId,
    sourceTitle: `MetroPT-3 字段：${row.fieldName}`,
    locator: `postgres:dataset_fields.dataset_id=${row.datasetId}&field_name=${row.fieldName}`,
    content: JSON.stringify({ fieldName: row.fieldName, dataType: row.dataType, meaning: row.meaning, unit: row.unit, labelRole: row.labelRole }),
    retrievalMethod: 'sql',
    relevanceScore: Math.max(0.7, 0.9 - index * 0.03),
    trustLevel: 'high',
    scope: 'system',
    metadata: { queryKind: 'field_definition', matchedTerms: patterns.join('、') },
  }));
}

async function genericDatasetEvidencePg(pool: Pool, terms: string[]): Promise<EvidenceItem[]> {
  const patterns = [...new Set(terms.filter((term) => term.length >= 2))].slice(0, 8);
  if (patterns.length === 0) return [];
  const clauses = patterns.map((_, index) => {
    const parameter = `$${index + 1}`;
    return `(LOWER(COALESCE(d.name, '')) LIKE ${parameter} OR LOWER(COALESCE(d.source_path, '')) LIKE ${parameter})`;
  }).join(' OR ');
  const datasets = (await pool.query(
    `SELECT d.id, d.name, d.source_path AS "sourcePath"
     FROM datasets d JOIN dataset_rows r ON r.dataset_id = d.id
     WHERE ${clauses}
     GROUP BY d.id ORDER BY d.id`,
    patterns.map((term) => `%${term}%`),
  )).rows as Array<{ id: string; name: string; sourcePath: string }>;
  const items: EvidenceItem[] = [];
  for (const dataset of datasets) {
    const rowCount = await getDatasetRowCountPg(pool, dataset.id);
    if (rowCount === 0) continue;
    items.push(evidenceItem({
      sourceType: 'dataset',
      sourceId: dataset.id,
      sourceTitle: `${dataset.name} 数据集`,
      locator: `postgres:datasets.id=${dataset.id}`,
      content: JSON.stringify({ dataset: dataset.name, rowCount, retrieval: '按标签抽样故障样本与正常样本' }),
      retrievalMethod: 'sql',
      relevanceScore: 0.9,
      trustLevel: 'high',
      scope: 'system',
      metadata: { queryKind: 'dataset_summary', rowCount },
    }));
    (await sampleDatasetRowsPg(pool, dataset.id, 3)).forEach((row, index) => {
      items.push(evidenceItem({
        sourceType: 'dataset',
        sourceId: dataset.id,
        sourceTitle: `${dataset.name} 代表性数据行`,
        locator: `postgres:dataset_rows.dataset_id=${dataset.id}&row_id=${row.rowId}`,
        content: JSON.stringify(row.fields),
        retrievalMethod: 'sql',
        relevanceScore: Math.max(0.6, 0.84 - index * 0.04),
        trustLevel: 'high',
        scope: 'system',
        metadata: { queryKind: 'dataset_row', rowId: row.rowId },
      }));
    });
  }
  return items;
}

async function structuredEvidencePg(pool: Pool, query: string, terms: string[]): Promise<EvidenceItem[]> {
  const intent = structuredIntent(query, terms);
  if (!intent) return [];
  const items: EvidenceItem[] = [];
  if (intent.metroRelevant) {
    const summary = await getMetroSummaryPg(pool);
    items.push(evidenceItem({
      sourceType: 'dataset',
      sourceId: summary.id,
      sourceTitle: `${summary.name} 数据集摘要`,
      locator: `postgres:datasets.id=${summary.id}`,
      content: JSON.stringify({
        dataset: summary.name,
        rowCount: summary.rowCount,
        fieldCount: summary.fieldCount,
        firstTimestamp: summary.firstTimestamp,
        lastTimestamp: summary.lastTimestamp,
      }),
      retrievalMethod: 'sql',
      relevanceScore: 0.92,
      trustLevel: 'high',
      scope: 'system',
      metadata: { queryKind: 'dataset_summary', matchedTerms: terms.join('、'), rowCount: summary.rowCount, fieldCount: summary.fieldCount },
    }));
    items.push(...await datasetFieldEvidencePg(pool, terms));
    if (intent.wantsRows) {
      const rows = await queryMetroReadingsPg(pool, 6, query);
      items.push(...rows.map((row, index) => evidenceItem({
        sourceType: 'dataset',
        sourceId: summary.id,
        sourceTitle: 'MetroPT-3 相关数据行',
        locator: `postgres:metro_readings.row_id=${row.rowId}`,
        content: JSON.stringify(row),
        retrievalMethod: 'sql',
        relevanceScore: Math.max(0.58, 0.86 - index * 0.04),
        trustLevel: 'high',
        scope: 'system' as EvidenceScope,
        metadata: { queryKind: 'query_matched_rows', rowId: row.rowId, timestamp: row.timestamp, matchedTerms: terms.join('、') },
      })));
    }
  }
  if (intent.wantsDatasets) items.push(...await genericDatasetEvidencePg(pool, terms));
  return items;
}

async function persistEvidencePg(pool: Pool, item: EvidenceItem): Promise<void> {
  await pool.query(
    `INSERT INTO evidence_items
      (id, source_type, source_id, source_title, locator, content, retrieval_method,
       relevance_score, trust_level, source_scope, metadata_json, created_at)
     VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12)
     ON CONFLICT (id) DO UPDATE SET
       source_title = excluded.source_title, locator = excluded.locator, content = excluded.content,
       relevance_score = excluded.relevance_score, metadata_json = excluded.metadata_json`,
    [
      item.id, item.sourceType, item.sourceId, item.sourceTitle ?? null, item.locator, item.content,
      item.retrievalMethod, item.relevanceScore, item.trustLevel, item.scope ?? 'system',
      JSON.stringify(item.metadata ?? {}), Date.now(),
    ],
  );
}

async function persistPackPg(pool: Pool, pack: EvidencePack): Promise<void> {
  await pool.query(
    `INSERT INTO evidence_packs
      (id, learner_id, session_id, query, retrieval_plan_json, coverage_score,
       cross_validation_json, privacy_json, created_at)
     VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
     ON CONFLICT (id) DO UPDATE SET
       retrieval_plan_json = excluded.retrieval_plan_json, coverage_score = excluded.coverage_score,
       cross_validation_json = excluded.cross_validation_json, privacy_json = excluded.privacy_json`,
    [
      pack.id, pack.learnerId ?? null, pack.sessionId ?? null, pack.query,
      JSON.stringify(pack.retrievalPlan), pack.coverageScore, JSON.stringify(pack.crossValidation), JSON.stringify(pack.privacy), pack.createdAt,
    ],
  );
  for (let index = 0; index < pack.items.length; index += 1) {
    await pool.query(
      `INSERT INTO evidence_pack_items (pack_id, evidence_id, position) VALUES ($1, $2, $3)
       ON CONFLICT (pack_id, evidence_id) DO UPDATE SET position = excluded.position`,
      [pack.id, pack.items[index]!.id, index],
    );
  }
}

export interface EvidenceBuildOptions {
  learnerId?: string;
  sessionId?: string;
  temporaryReference?: { name: string; content: string } | null;
  /** DAG 检索节点按路径拆分：不传 = 双路全检（docs/挑战杯技术开发总规.md §5.2） */
  retrievalPlan?: Array<'structured' | 'document'>;
  /** false 时禁用；force 供 Claim 反证复核使用；缺省按触发条件自动决定。 */
  webSearch?: boolean | 'force';
}

function coverageScoreOf(documentCount: number, structuredCount: number, webCount = 0): number {
  // 网络摘要只能小幅补全覆盖面，永远不能替代本地文档与结构化数据的权重。
  const score = 0.35
    + Math.min(0.35, documentCount * 0.06)
    + Math.min(0.3, structuredCount * 0.04)
    + Math.min(0.12, webCount * 0.025);
  return Math.min(1, Math.round(score * 100) / 100);
}

async function recordBlockedWebSearch(
  pool: Pool,
  query: string,
  options: Pick<EvidenceBuildOptions, 'learnerId' | 'sessionId'>,
  redactedFields: string[],
): Promise<void> {
  if (redactedFields.length === 0) return;
  await pool.query(
    `INSERT INTO privacy_audit_events
      (id, learner_id, session_id, event_type, file_name, byte_count, content_hash, redacted_fields_json, retained, created_at)
     VALUES ($1, $2, $3, $4, NULL, NULL, $5, $6, false, $7)`,
    [
      `privacy-${randomUUID()}`,
      options.learnerId ?? null,
      options.sessionId ?? null,
      'web_search_blocked',
      createHash('sha256').update(query).digest('hex'),
      JSON.stringify(redactedFields),
      Date.now(),
    ],
  );
}

export class PgEvidenceService {
  constructor(private readonly pool: Pool) {}

  async getCatalog(): Promise<DatasetSummary> {
    return getMetroSummaryPg(this.pool);
  }

  getWebSearchStatus() {
    return getSearxngStatus();
  }

  async buildEvidencePack(query: string, options: EvidenceBuildOptions = {}): Promise<EvidencePack> {
    const wantStructured = !options.retrievalPlan || options.retrievalPlan.includes('structured');
    const wantDocuments = !options.retrievalPlan || options.retrievalPlan.includes('document');
    const terms = normalizeSearchTerms(query);
    const structured = wantStructured ? await structuredEvidencePg(this.pool, query, terms) : [];
    let documents: EvidenceItem[] = [];
    let hybrid: EvidencePack['hybrid'];
    if (wantDocuments) {
      const result = await hybridDocumentRowsPg(this.pool, toTsQuery(terms), query);
      hybrid = result.hybrid;
      documents = result.rows.map((row, index) => evidenceItem({
        sourceType: 'document',
        sourceId: row.sourceId,
        sourceTitle: row.title,
        locator: `${row.sourcePath}#${row.locator}`,
        content: row.content,
        retrievalMethod: row.via === 'vector' ? 'vector' : 'fts',
        relevanceScore: Math.max(0.55, 0.94 - index * 0.06),
        trustLevel: 'high',
        scope: 'system' as EvidenceScope,
        metadata: { title: row.title, termsMatched: terms.length, via: row.via },
      }));
    }
    const localCoverage = coverageScoreOf(documents.length, structured.length);
    const config = getSearxngConfig();
    const trigger = wantDocuments && options.webSearch !== false && config.enabled
      ? options.webSearch === 'force'
        ? 'claim_review'
        : chooseWebSearchTrigger(query, documents.length, localCoverage, config)
      : null;
    let webSearch: EvidenceItem[] = [];
    let webSearchInfo: EvidencePack['webSearch'];
    if (trigger) {
      const outcome = await searchSearxng(query, config);
      webSearch = outcome.results.map((result, index) => evidenceItem({
        sourceType: 'web_search',
        sourceId: result.url,
        sourceTitle: result.title,
        locator: result.url,
        content: result.content,
        retrievalMethod: 'web',
        relevanceScore: Math.max(0.42, 0.62 - index * 0.04),
        trustLevel: 'low',
        scope: 'web_search',
        metadata: {
          provider: 'searxng',
          queryKind: 'web_search',
          engines: result.engines.join(', ') || 'unknown',
          ...(result.publishedDate ? { publishedDate: result.publishedDate } : {}),
        },
      }));
      webSearchInfo = {
        provider: 'searxng',
        trigger,
        attempted: outcome.reason !== 'privacy_filtered',
        resultCount: webSearch.length,
        ...(outcome.reason ? { reason: outcome.reason } : {}),
      };
      if (outcome.reason === 'privacy_filtered') {
        await recordBlockedWebSearch(this.pool, query, options, outcome.redactedFields ?? []);
      }
      if (outcome.results.length > 0) {
        // 候选账本是增强能力：数据库治理表不可用时不影响本次证据检索与回答。
        try {
          await persistWebSearchCandidates(this.pool, { query, results: outcome.results });
        } catch {
          // 仅记录通用事件，避免把连接串或用户查询写入日志。
          console.warn('[web-search] 候选登记未完成，本次结果仍保留在 EvidencePack');
        }
      }
    }
    const items = [...structured, ...documents, ...webSearch];
    for (const item of items) await persistEvidencePg(this.pool, item);
    const crossValidation = crossValidate(items);
    const pack: EvidencePack = {
      id: `evidence-pack-${randomUUID()}`,
      query,
      items,
      retrievalPlan: [
        ...(wantStructured && structured.length > 0 ? ['structured' as const] : []),
        ...(wantDocuments && documents.length > 0 ? ['document' as const] : []),
        ...(webSearch.length > 0 ? ['web_search' as const] : []),
      ],
      coverageScore: coverageScoreOf(documents.length, structured.length, webSearch.length),
      crossValidation,
      structuredCount: structured.length,
      documentCount: documents.length,
      temporaryCount: (options.temporaryReference ? 1 : 0) + webSearch.length,
      privacy: { temporaryReferenceUsed: Boolean(options.temporaryReference), retained: false },
      hybrid,
      ...(webSearchInfo ? { webSearch: webSearchInfo } : {}),
      learnerId: options.learnerId,
      sessionId: options.sessionId,
      createdAt: Date.now(),
    };
    await persistPackPg(this.pool, pack);
    if (options.temporaryReference) {
      await this.pool.query(
        `INSERT INTO privacy_audit_events
          (id, learner_id, session_id, event_type, file_name, byte_count, content_hash, redacted_fields_json, retained, created_at)
         VALUES ($1, $2, $3, $4, $5, $6, $7, $8, false, $9)`,
        [
          `privacy-${randomUUID()}`,
          options.learnerId ?? null,
          options.sessionId ?? null,
          'temporary_reference_used',
          options.temporaryReference.name.slice(0, 160),
          Buffer.byteLength(options.temporaryReference.content, 'utf8'),
          createHash('sha256').update(options.temporaryReference.content).digest('hex'),
          JSON.stringify([]),
          Date.now(),
        ],
      );
    }
    return pack;
  }

  /** DAG 合并证据包复用同一持久化通道（幂等 upsert） */
  async persistEvidencePack(pack: EvidencePack): Promise<void> {
    for (const item of pack.items) await persistEvidencePg(this.pool, item);
    await persistPackPg(this.pool, pack);
  }
}

/* ------------------------------------------------------------------ */
/* 干净环境引导（Compose bootstrap）：种子目录 / 知识卡 / CSV / Metro     */
/* ------------------------------------------------------------------ */

export async function seedMetroCatalogPg(pool: Pool): Promise<void> {
  await pool.query(
    `INSERT INTO datasets (id, name, source_kind, source_path, version, license, checksum, imported_at)
     VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
     ON CONFLICT (id) DO UPDATE SET name = excluded.name, imported_at = excluded.imported_at`,
    ['metropt-3', 'MetroPT-3 Air Compressor', 'industrial_dataset',
      'IM-Training-Agent-datasets/raw/MetroPT-3.zip::MetroPT3(AirCompressor).csv', '2020',
      'See bundled source metadata', '', Date.now()],
  );

  const fields: Array<[string, string, string, string, string]> = [
    ['timestamp', 'TEXT', '采样时间', '', 'time'],
    ['TP2', 'REAL', '压缩机压力观测量', 'bar', 'sensor'],
    ['TP3', 'REAL', '气动面板产生的压力', 'bar', 'sensor'],
    ['H1', 'REAL', '旋风分离器排放产生的压力下降', 'bar', 'sensor'],
    ['DV_pressure', 'REAL', '干燥塔排气时产生的压力下降；为零表示压缩机带载运行', 'bar', 'sensor'],
    ['Reservoirs', 'REAL', '储气罐下游压力，应接近 TP3', 'bar', 'sensor'],
    ['Oil_temperature', 'REAL', '压缩机油温', '°C', 'sensor'],
    ['Motor_current', 'REAL', '三相电机一相的电流，约 0/4/7/9A 对应不同工作状态', 'A', 'sensor'],
    ['COMP', 'REAL', '压缩机进气阀电信号', '', 'state'],
    ['DV_eletric', 'REAL', '压缩机出口阀控制信号', '', 'state'],
    ['Towers', 'REAL', '干燥塔与排湿塔的切换信号', '', 'state'],
    ['MPG', 'REAL', 'APU 压力低于约 8.2 bar 时启动带载运行的信号', '', 'state'],
    ['LPS', 'REAL', '压力低于约 7 bar 时触发的低压开关信号', '', 'state'],
    ['Pressure_switch', 'REAL', '检测干燥塔排放的电信号', '', 'state'],
    ['Oil_level', 'REAL', '油位低于预期值时触发的信号', '', 'state'],
    ['Caudal_impulses', 'REAL', '从 APU 流向储气罐的空气流量脉冲计数', '', 'sensor'],
  ];
  for (const [name, dataType, meaning, unit, role] of fields) {
    await pool.query(
      `INSERT INTO dataset_fields (id, dataset_id, field_name, data_type, meaning, unit, label_role)
       VALUES ($1, $2, $3, $4, $5, $6, $7)
       ON CONFLICT (id) DO UPDATE SET meaning = excluded.meaning, label_role = excluded.label_role`,
      [`metropt-3-field-${name}`, 'metropt-3', name, dataType, meaning, unit, role],
    );
  }

  const chunks: Array<[string, string, string, string, string]> = [
    ['metropt-3-pdf-overview', 'MetroPT-3 数据集概览', 'MetroPT-3 来自列车空气生产单元（APU）的工业空气压缩机多变量时序数据，可用于故障预测、异常解释和预测性维护训练。数据包同时包含 CSV 原始记录和本 PDF 数据说明。', 'raw/MetroPT-3.zip::Data Description_Metro.pdf', 'PDF p.1'],
    ['metropt-3-pdf-collection', 'MetroPT-3 采集方式', '数据覆盖 2020 年 2 月至 8 月，记录压力、温度、电机电流及进气阀等 15 个信号。数据说明标注为工业设备传感器记录，使用时应以实际 CSV 行数和时间戳为准。', 'raw/MetroPT-3.zip::Data Description_Metro.pdf', 'PDF p.1-p.2'],
    ['metropt-3-evidence-rule', '数据证据使用边界', '传感器异常只能支持风险判断，不能直接证明设备已经发生确定故障。生成维护建议时必须同时展示数据定位、必要的现场复核和不确定性。', 'raw/MetroPT-3.zip::Data Description_Metro.pdf', 'PDF p.3'],
    ['metropt-3-paper-source', 'MetroPT-3 研究来源', '数据说明列出 Predictive maintenance based on anomaly detection using deep learning for air production unit in the railway industry，以及 The MetroPT dataset for predictive maintenance 等相关研究来源。', 'raw/MetroPT-3.zip::Data Description_Metro.pdf', 'PDF p.1-p.2'],
  ];
  fields.slice(1).forEach(([name, , meaning, unit]) => {
    chunks.push([
      `metropt-3-field-${name.toLowerCase()}`,
      `字段说明：${name}`,
      `${name}：${meaning}${unit ? ` 单位为 ${unit}。` : '。'}字段含义必须以数据说明和查询结果为准，不允许模型凭空补全。`,
      'raw/MetroPT-3.zip::Data Description_Metro.pdf',
      'PDF p.2-p.3',
    ]);
  });
  const failureWindows: Array<[string, string, string, string]> = [
    ['metropt-3-failure-1', '故障窗口 #1', '2020-04-18 00:00 至 2020-04-18 23:59，报告为 Air leak，严重程度 High stress。', 'PDF p.3'],
    ['metropt-3-failure-2', '故障窗口 #2', '2020-05-29 23:30 至 2020-05-30 06:00，报告为 Air Leak，严重程度 High stress；记录 4 月 30 日有维护。', 'PDF p.3'],
    ['metropt-3-failure-3', '故障窗口 #3', '2020-06-05 10:00 至 2020-06-07 14:30，报告为 Air Leak，严重程度 High stress；记录 6 月 8 日有维护。', 'PDF p.3'],
    ['metropt-3-failure-4', '故障窗口 #4', '2020-07-15 14:30 至 2020-07-15 19:00，报告为 Air Leak，严重程度 High stress；记录 7 月 16 日有维护。', 'PDF p.3'],
  ];
  for (const [id, label, description, locator] of failureWindows) {
    const match = description.match(/(\d{4}-\d{2}-\d{2} \d{2}:\d{2}) 至 (\d{4}-\d{2}-\d{2} \d{2}:\d{2})/);
    if (!match) continue;
    await pool.query(
      `INSERT INTO metro_event_windows (id, dataset_id, label, start_at, end_at, source_locator)
       VALUES ($1, $2, $3, $4, $5, $6)
       ON CONFLICT (id) DO UPDATE SET label = excluded.label, start_at = excluded.start_at, end_at = excluded.end_at`,
      [id, 'metropt-3', label, match[1], match[2], `raw/MetroPT-3.zip::Data Description_Metro.pdf#${locator}`],
    );
    chunks.push([id, label, description, 'raw/MetroPT-3.zip::Data Description_Metro.pdf', locator]);
  }

  await pool.query("DELETE FROM document_chunks WHERE id IN ('metropt-3-overview', 'metropt-3-field-guide')");
  for (const [id, title, content, sourcePath, locator] of chunks) {
    await upsertDocumentChunkPg(pool, { id, sourceId: 'metropt-3', sourcePath, title, content, locator, trustLevel: 'high' });
  }
}

export interface DocumentChunkSeed {
  id: string;
  sourceId: string;
  sourcePath: string;
  title: string;
  content: string;
  locator: string;
  trustLevel: string;
}

export async function upsertDocumentChunkPg(pool: Pool, chunk: DocumentChunkSeed): Promise<void> {
  await pool.query(
    `INSERT INTO document_chunks (id, source_id, source_path, title, content, search_text, locator, trust_level, created_at)
     VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
     ON CONFLICT (id) DO UPDATE SET
       title = excluded.title, content = excluded.content, search_text = excluded.search_text,
       locator = excluded.locator, trust_level = excluded.trust_level,
       -- 内容未变保留已回填的向量；内容变化才置空待重回填（避免 bootstrap 重导抹掉全部向量）
       embedding = CASE WHEN document_chunks.search_text = excluded.search_text THEN document_chunks.embedding ELSE NULL END`,
    [chunk.id, chunk.sourceId, chunk.sourcePath, chunk.title, chunk.content,
      `${chunk.title}\n${chunk.content}`, chunk.locator, chunk.trustLevel, Date.now()],
  );
}

/** 知识卡导入（PG 版）：data/knowledge 目录是“丢弃式”知识层，幂等整体重导。 */
export async function importKnowledgeCardsPg(pool: Pool, dir?: string): Promise<{ imported: number; chunks: number }> {
  const cardDir = dir ?? path.resolve(process.cwd(), 'data', 'knowledge');
  if (!existsSync(cardDir)) return { imported: 0, chunks: 0 };
  const files = readdirSync(cardDir).filter((file) => file.toLowerCase().endsWith('.md')).sort();
  if (files.length === 0) return { imported: 0, chunks: 0 };

  interface ParsedCardMeta { id: string; title: string; source: string; locator: string; datasetId: string; trust: string; }
  interface ParsedCard { meta: ParsedCardMeta; content: string; file: string; }
  const cards: ParsedCard[] = [];
  for (const file of files) {
    const raw = readFileSync(path.join(cardDir, file), 'utf8');
    const normalized = raw.replace(/^\uFEFF/, '').trim();
    if (!normalized.startsWith('---')) continue;
    const end = normalized.indexOf('\n---', 3);
    if (end < 0) continue;
    const header = normalized.slice(3, end);
    const content = normalized.slice(end + 4).trim();
    const meta: ParsedCardMeta = {
      id: file.replace(/\.md$/i, '').toLowerCase(),
      title: '', source: '系统知识卡', locator: file, datasetId: KNOWLEDGE_CARD_SOURCE_ID, trust: 'high',
    };
    for (const line of header.split('\n')) {
      const match = line.match(/^([A-Za-z]+)\s*:\s*(.+)$/);
      if (!match) continue;
      const key = match[1];
      const value = (match[2] ?? '').trim();
      if (key === 'id') meta.id = value.toLowerCase() || meta.id;
      else if (key === 'title') meta.title = value;
      else if (key === 'source') meta.source = value;
      else if (key === 'locator') meta.locator = value;
      else if (key === 'dataset' && value) meta.datasetId = value;
      else if (key === 'trust' && value) meta.trust = value;
    }
    if (meta.id && meta.title && content) cards.push({ meta, content, file });
  }

  await pool.query('DELETE FROM document_chunks WHERE source_id = $1', [KNOWLEDGE_CARD_SOURCE_ID]);
  let chunks = 0;
  for (const card of cards) {
    const parts = chunkCardContent(card.content);
    chunks += parts.length;
    for (let index = 0; index < parts.length; index += 1) {
      const part = parts[index]!;
      const id = parts.length === 1 ? `card-${card.meta.id}` : `card-${card.meta.id}#c${String(index + 1).padStart(2, '0')}`;
      const title = part.heading ? `${card.meta.title} · ${part.heading}` : card.meta.title;
      await upsertDocumentChunkPg(pool, {
        id,
        sourceId: card.meta.datasetId,
        sourcePath: `data/knowledge/${card.file}`,
        title: title.length > 180 ? `${title.slice(0, 179)}…` : title,
        content: part.text,
        locator: card.meta.locator,
        trustLevel: card.meta.trust,
      });
    }
  }
  return { imported: cards.length, chunks };
}

/** 声明式 CSV 数据集导入（PG 版，AI4I 等小体量数据集）：文件未变跳过，换文件自动重导。 */
export async function importCsvDatasetPg(pool: Pool, source: CsvDatasetSource): Promise<{ imported: boolean; rowCount: number }> {
  if (!existsSync(source.csvPath)) return { imported: false, rowCount: 0 };
  const csv = readFileSync(source.csvPath, 'utf8');
  const checksum = createHash('sha256').update(csv).digest('hex');

  const existing = (await pool.query('SELECT checksum FROM datasets WHERE id = $1', [source.id])).rows[0] as { checksum?: string | null } | undefined;
  const rowCountRow = (await pool.query('SELECT COUNT(*) AS count FROM dataset_rows WHERE dataset_id = $1', [source.id])).rows[0] as { count: string | number };
  const currentRowCount = Number(rowCountRow.count);
  if (existing?.checksum === checksum && currentRowCount > 0) return { imported: false, rowCount: currentRowCount };

  const { header, rows } = parseCsv(csv);
  if (header.length === 0 || rows.length === 0) return { imported: false, rowCount: 0 };

  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    await client.query('DELETE FROM dataset_rows WHERE dataset_id = $1', [source.id]);
    for (let index = 0; index < rows.length; index += 1) {
      const cells = rows[index]!;
      const record: Record<string, string | number | null> = {};
      header.forEach((name, columnIndex) => {
        const rawValue = (cells[columnIndex] ?? '').trim();
        const numberValue = inferNumber(rawValue);
        record[name] = numberValue === null ? rawValue : numberValue;
      });
      await client.query('INSERT INTO dataset_rows (dataset_id, row_id, data_json) VALUES ($1, $2, $3)', [source.id, index + 1, record]);
    }
    await client.query(
      `INSERT INTO datasets (id, name, source_kind, source_path, version, license, checksum, imported_at)
       VALUES ($1, $2, 'csv_dataset', $3, '1.0', $4, $5, $6)
       ON CONFLICT (id) DO UPDATE SET name = excluded.name, checksum = excluded.checksum, imported_at = excluded.imported_at`,
      [source.id, source.name, source.sourcePath, source.license, checksum, Date.now()],
    );
    const firstRow = rows[0];
    if (firstRow) {
      for (let columnIndex = 0; columnIndex < header.length; columnIndex += 1) {
        const name = header[columnIndex]!;
        const numeric = inferNumber((firstRow[columnIndex] ?? '').trim()) !== null;
        const labelRole = source.labelFields?.includes(name) ? 'label' : 'feature';
        const unitMatch = name.match(/\[([^\]]+)\]/);
        await client.query(
          `INSERT INTO dataset_fields (id, dataset_id, field_name, data_type, meaning, unit, label_role)
           VALUES ($1, $2, $3, $4, $5, $6, $7)
           ON CONFLICT (id) DO UPDATE SET data_type = excluded.data_type, meaning = excluded.meaning, label_role = excluded.label_role`,
          [`${source.id}-field-${name}`, source.id, name, numeric ? 'REAL' : 'TEXT',
            source.fieldMeanings?.[name] ?? '数据字段', unitMatch?.[1] ?? '', labelRole],
        );
      }
    }
    await client.query('COMMIT');
  } catch (error) {
    await client.query('ROLLBACK');
    throw error;
  } finally {
    client.release();
  }
  return { imported: true, rowCount: rows.length };
}

function inferNumber(value: string): number | null {
  if (value.trim() === '') return null;
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : null;
}

/** 小而美的 CSV 解析：覆盖引号、转义引号与换行。 */
function parseCsv(text: string): { header: string[]; rows: string[][] } {
  const cleaned = text.replace(/^\uFEFF/, '');
  const rows: string[][] = [];
  let row: string[] = [];
  let field = '';
  let inQuotes = false;
  for (let index = 0; index < cleaned.length; index += 1) {
    const char = cleaned[index]!;
    if (inQuotes) {
      if (char === '"') {
        if (cleaned[index + 1] === '"') { field += '"'; index += 1; } else inQuotes = false;
      } else field += char;
      continue;
    }
    if (char === '"') { inQuotes = true; continue; }
    if (char === ',') { row.push(field); field = ''; continue; }
    if (char === '\n' || char === '\r') {
      if (char === '\r' && cleaned[index + 1] === '\n') index += 1;
      row.push(field);
      field = '';
      if (row.some((item) => item.trim().length > 0)) rows.push(row);
      row = [];
      continue;
    }
    field += char;
  }
  row.push(field);
  if (row.some((item) => item.trim().length > 0)) rows.push(row);
  const header = rows[0]?.map((name) => name.trim()) ?? [];
  return { header, rows: rows.slice(1) };
}

/** MetroPT-3 完整 CSV 导入（PG 版）：COPY 流式装载，仅空表时执行，1,516,948 行约 40-60 秒。 */
export async function importMetroPt3CsvPg(pool: Pool, csvPath: string): Promise<{ imported: number; skipped: boolean }> {
  const existing = (await pool.query('SELECT COUNT(*) AS count FROM metro_readings')).rows[0] as { count: string | number };
  if (Number(existing.count) > 0) return { imported: Number(existing.count), skipped: true };
  if (!existsSync(csvPath)) return { imported: 0, skipped: false };

  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const stream = client.query(copyFrom(`
      COPY metro_readings (row_id, timestamp, tp2, tp3, h1, dv_pressure, reservoirs,
        oil_temperature, motor_current, comp, dv_electric, towers,
        mpg, lps, pressure_switch, oil_level, caudal_impulses)
      FROM STDIN WITH (FORMAT csv, HEADER true)
    `));
    await pipeline(createReadStream(csvPath, { encoding: 'utf8' }), stream);
    await client.query('COMMIT');
  } catch (error) {
    await client.query('ROLLBACK');
    throw error;
  } finally {
    client.release();
  }
  const after = (await pool.query('SELECT COUNT(*) AS count FROM metro_readings')).rows[0] as { count: string | number };
  return { imported: Number(after.count), skipped: false };
}

export type { PoolClient };
