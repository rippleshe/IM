[ERROR] - (starship::print): Under a 'dumb' terminal (TERM=dumb).

# 阅读进度

## 2026-08-30 提交材料按用户要求收敛：12 份 → 7 份

- 对照赛题「作品提交形式」重新梳理必要集：材料文档（设计实现方案/作品介绍/视频）、软件模块（源代码/部署说明/单元测试用例）、测试数据（知识库切片 + 三画像数据包）。
- 删除 6 份非必要文档（多智能体可信协同协议 / 幻觉治理与知识溯源说明 / 数据合规与隐私说明 / 领域迁移指南 / 用户使用手册 / 答辩问答准备），其内容压缩并入《作品设计实现方案》对应章节；《提交检查清单》并入 submission/README.md。
- 重命名：部署与故障排查说明 → 部署说明；演示视频脚本与分镜 → 演示视频脚本。
- 新增：单元测试说明.md（对应赛题"单元测试用例"要求，指向仓库内 23 文件/163 用例）、README.md（提交物 ↔ 仓库对应物映射 + 项目迭代后需刷新的提交物清单 + 精简核对）。
- 升级计划文档中里程碑 H 的文档清单同步更新为 7 份；无孤儿引用。
- 最终状态：typecheck 0 错、22 文件 / 163 测试全过。

## 2026-08-29 里程碑 H 完成：比赛材料与提交包（+ 全计划收尾）

- `docs/submission/` 12 份文档全部落盘：作品设计实现方案、作品介绍、多智能体可信协同协议（VACP）、幻觉治理与知识溯源说明、评测方案与结果报告、数据合规与隐私说明、部署与故障排查说明、用户使用手册、领域迁移指南、演示视频脚本与分镜、答辩问答准备、提交检查清单。
- 三画像提交数据包重新生成（新协议口径）：foundation / advanced / maintenance 各一次真实运行并导出 `data/exports/{persona}-run-export.json`（374KB / 365KB / 455KB）；三包全部通过 `pnpm verify:export` 八项完整性校验（产物散列、DAG 闭合、事件 seq、inputRefs、Claim—Evidence、裁决只紧不松、发布 fail-closed、敏感字段）+ manifest 在线对照一致。
- 最硬的门禁增益证据：maintenance 包离线回放 `pnpm replay:run` —— 初稿幻觉率 25.0% → 终稿 0.0%（门禁净增益 25 个百分点），三轮回放与在线裁决完全一致；foundation/advanced 各含 1 次修订后放行。
- 新增运行列表端点 GET /api/learning/runs（验证页运行选择区，learner 隔离）。
- 最终回归：typecheck 0 错误、23 文件 / 163 测试全过、web tsc + 生产构建通过；api(3001)/worker/web(3000) 运行中。
- 完成定义（升级计划 §8.4）对照：11 项中 10 项达成；第 7/8 项中的"60 案例全量 live"按计划自身约束需用户授权调用量后执行 `pnpm evaluate --live`（报告口径已支持分层 + 如实标注），当前以"离线全量 + 分层 live + 存量运行 + 离线回放"四层证据如实呈现。
- 全程流量约束遵守：未下载任何依赖/数据/模型；live 模型调用仅限产品正常运行的协同生成（3 画像数据包 + 冒烟验证），`IM_TRAINING_AGENT_ALLOW_LIVE_EVAL` 评测开关保持 false。

## 2026-08-29 里程碑 G 完成：前端验证页与三工作台轻量增强

- 新增 `web/src/components/validation-workbench.tsx`（验证页）：运行选择区（GET /runs 列表）、可信摘要（证据数/事实声明/终稿无证据/待复核/修订轮数/发布结论）、协同链（按节点折叠展示 actor、公开结论、输入引用、产物散列、生产者）、声明证据表（claimTrace 聚组表格：类型/轮次/终稿结论/证据定位/质询议题）、前后对照（各修订轮计数与裁决）、离线校验（POST /verify 七项 checks + 回放对照）、导出入口；支持 localStorage 预填 runId。
- page.tsx 顶部视图新增 `validation`；四个页面导航统一加入「验证」项。
- 学习页：运行结束后显示"查看验证记录"入口（携带 runId 跳验证页）。
- 路径页：节点详情新增"依据"面板——最近一次持久化学习决策（触发来源、BKT 前后值、理由、系统决策与推荐资源）。
- 资源页：新增可信溯源条（门禁状态、难度校准、来源 runId、"查看验证记录"跳转）。
- 画像弹窗：新增"最近一次状态变化"区块（触发来源、BKT before/after、理由、下一步）；难度曲线注明预测值与实际作答口径。
- 修复历史缺陷（冒烟发现）：修订环被调度器误跳过——裁决未放行进入修订轮后，dispatch 的 skipRemaining 把刚入队的修订节点跳过并错误收尾为 succeeded（这正是 G10"20 个历史运行零修订"的根因）；修复为按 adjudication.outcome 区分 revised/rejected，rejected 路径补齐 publication_decision 产物 + generation_end 快照 + manifest；audit 跳过 evidence 块（定位信息不是事实声明）。
- 端到端冒烟（2 个临时账号 + 3 次真实运行，完成后清理）：修订轮机械链路 1→2→3 走通；unsupported 声明 3→2→1 收敛（修订环增益可见）；预算用尽 fail-closed 后 19 产物 + 双快照 + manifest + POST /verify 七项全过；learner-advanced 的一次完整运行保留为演示产物。
- 验证：根 typecheck 0 错、163 测试全过；web tsc 0 错、生产构建通过；api:3001 / worker / web:3000 重启后健康。
- 冒烟临时账号与数据已按表清空（0 残留、0 孤儿产物）；未发生计划外网络下载。

## 2026-08-29 里程碑 F 完成：离线回放、指标与消融

- 新增 `server/runs/metrics.ts`：官方三项指标口径（幻觉率 non_factual 不入分母、空分母 N/A；难度适配/覆盖率判定函数）+ 补充指标（初稿/终稿幻觉率、门禁净增益、有效质询率）+ verifyExportIntegrity（七项完整性校验：artifact hash 重算、DAG 闭合、事件 seq 连续、inputRefs、Claim—Evidence 悬空、裁决只紧不松、发布 fail-closed、敏感字段扫描）+ replayExport（按轮次重算规则门禁与在线裁决对照）。
- 新增脚本：`pnpm verify:export`（导出包完整性校验）、`pnpm replay:run`（离线回放，退出码语义化）、`pnpm gold:export`（黄金标注导出）；新增 `scripts/export-gold-labels.ts` 并生成 data/evaluation/{gold-cases,gold-knowledge-points,personas}.json 三个固定黄金标注文件。
- 指标口径修正（evaluation.ts）：hallucinationRate 改为官方口径（review 在分母、non_factual 排除、空分母 null）+ 新增 draftFinalHallucinationRates（修 G10）；evaluate.ts live 覆盖率改为证据边口径（资源块绑定知识点 × supported Claim 的 evidence edge，修 G9），报告显式区分 resultScope（offline_rule_60 / stratified_live_N + offline_full_60）。
- 消融 A2 重写（修 G10）：按 attempt 轮次统计初稿/终稿幻觉率与门禁净增益（non_factual 排除），历史 20 次运行 A1 分化 3 种计划、A2 终稿幻觉率 0、A3 33/33 入区间全过。
- API：POST /api/learning/runs/:runId/verify（离线规则复算，返回完整性 checks + manifest 对照 + replay 轮次明细）；export 重构为共享构建器 buildRunExportPayload。
- 验证：typecheck 0 错误；23 文件 / 163 测试全过（新增 metrics 13 用例：篡改 hash 发现、悬空 evidence edge 发现、裁决放松发现、seq 缺口、敏感字段、fail-closed 发布校验、口径与净增益）；pnpm evaluate 离线 60 案例全过；pnpm ablation 三组全过。
- 未发生网络下载与 live 模型调用。

## 2026-08-29 里程碑 E 完成：反馈驱动的持久化学习决策

- 新增 `src/learning/decision.ts`：学习决策纯函数（remediate/continue/advance/collect_more_evidence 四态；低掌握或连续错误→补强、掌握高但置信不足→同级采样、双达标→进阶、反馈冲突或证据不足→先追问；先修缺口大优先讲义、补强资源轮换避免重复）+ decisionToRecommendationLevel 路径建议映射；理由携带真实 BKT 前后值。
- schema/迁移 0010：`learning_decisions` 表（learner/run/asset/kp/trigger/input_snapshot_id/decision/推荐资源/rationale），CHECK 约束 + 双索引，已应用。
- 新增 `server/decision-service.ts`：recordLearningDecision（先固化 feedback_update 学情快照→纯函数决策→落库+learning_event，fail-open 不阻断作答主流程）、listDecisions（learner 隔离）、latestDecisionByKnowledgePoint、latestBktUpdate/assetAttemptStats/prereqGapFor 查询辅助。
- 端点接入：quiz-attempts 与 asset feedback 提交后自动记录决策（PG 模式）；新增 GET /api/learning/decisions。
- 路径建议改造（G12）：pg-store getRecommendationEvidence 增载每知识点最近持久化决策，recommendationForNode 优先消费（level 映射 + 理由合并），缺失时回退 computeNodeRecommendation。
- StudyRunRequest 新增 sourceDecisionId（parse/校验、design_constraints 产物记录），形成"反馈→决策→下一运行"链。
- 验证：typecheck 0 错误；21 文件 / 152 测试全过（新增决策 9 用例：四态全覆盖、资源轮换、冲突追问、BKT 前后值可追溯）。
- 未发生网络下载与 live 模型调用。

## 2026-08-29 里程碑 D 完成：声明级幻觉治理与独立质询裁决

- audit.ts 升级：新增 ClaimType 分类（numeric/field_meaning/method_step/causal/risk_advice/non_factual，确定性启发式可单测）与 claimLogicalKey（跨修订轮稳定键，规范化文本）；auditResource 产出 claimType/logicalKey，汇总口径排除 non_factual（不进分母、不阻断发布）。
- 新增 `src/learning/claim-verification.ts`：确定性核验纯函数——数值逐个与绑定证据比对、字段含义对 dataset_fields 字典、越界因果规则（绝对化表述无限定词 fail closed）、引用越界检查；结论只能比输入更严（supported→review→unsupported），绝不放松。
- executor 集成：runAuditClaims 逐条 verifyClaims（字段字典取自 PG dataset_fields）；persistClaims 写 runId/attempt/claimType/logicalKey/supersedesClaimId（按上一轮同 logicalKey 匹配）；裁决计数与修订回退列表排除 non_factual；裁决 Agent 输入补充反证检索结果（不读生成端对话）。
- 反证检索（里程碑 D 第 7 条）：批评 Agent 可提出 counterevidence_request（迁移 0009 扩展 CHECK），executor 在已有知识库/数据中执行反证检索（复用混合检索，不联网），命中项并入合并证据包供下一轮修订引用，结果写入 challenge_set 产物并如实展示未命中/失败。
- 新增 `server/runs/claim-trace.ts`：logicalKey 聚组的声明追溯链（初稿→质询→裁决→修订→终稿）+ hallucinationRateFromTrace（空分母返回 null 的 N/A 语义，修 G10 一部分）；已接入 GET /runs/:runId/trace。
- 验证：typecheck 0 错误；20 文件 / 143 测试全过（新增 11 个故障注入用例：错数字、数字一致、越界因果、字段含义写错、引用越界、无证据建议、核验只严不松、逻辑键稳定、non_factual 口径）；迁移 0009 已应用。
- 未发生网络下载与 live 模型调用。

## 2026-08-29 里程碑 C 完成：真实学情信号与检索后策略修正

- 新增 `server/runs/policy.ts`：taskFactRisk 纯函数（数值/因果/操作密度 + 资源类型风险）、deriveVerificationPolicy 纯函数（sparse 禁强事实/冲突从严/数值因果核验/低置信难度质询/降级如实记录，门禁只增不减）、defaultVerificationPolicy、deriveRiskLevelWithTaskRisk。
- 运行前信号（修 G5）：profile-insights 新增 computeRunLearnerSignals（profileUncertainty=1-目标+先修加权置信度、knowledgeRisk=0.5×近期错误率+0.3×先修缺口+0.2×掌握不确定性）与 prereqClosureOf（前置闭包 BFS）+ computePlannerKnowledgeSignals；routes 的 derivePlannerSignals 改为真实 BKT 信号驱动，planner 风险等级纳入 taskRisk。
- planner 输入固化：POST /runs 创建运行后立即写 design_constraints artifact（signals + 任务风险理由，producer=rule），不再只存在于 plan JSON。
- 检索后修正：analyze.domain 完成后由实际证据产物推导 policy；amended 时写 verification_policy_json + design_constraints（post_retrieval_policy）artifact + 追加 `plan.amended` 事件（protocol 已加事件类型）；生成端消费 forbidStrongFactualClaims（sparse 时 prompt 追加禁强事实约束）；裁决端消费 conflictMode/strength（partial 亦不放行）。
- 验证：typecheck 0 错误；19 文件 / 132 测试全过（新增 policy 测试矩阵 11 用例：空证据 sparse、冲突从严、降级门禁不减、低置信难度质询、高置信不放松、先修缺口计算、无先修权重回退、taskRisk 升级风险等级）。
- 未发生网络下载与 live 模型调用。

## 2026-08-29 里程碑 B 完成：VACP 产物层与起止快照

- schema/迁移：`collaboration_artifacts`（唯一键 run+node+attempt+type+actor）、`run_state_snapshots`（run_start/generation_end/feedback_update）两表落地；claims 补 run_id/attempt/draft_artifact_id/claim_type/logical_key/supersedes_claim_id，study_run_nodes 补 actor_key/primary_artifact_id，study_runs 补 start_snapshot_id/verification_policy_json/execution_manifest_hash；迁移 0008 全部 nullable/带默认值，历史行保留，已应用到 PG 并核对表结构。
- 新增 `server/runs/artifacts.ts`：ActorKey（10 执行者）与节点映射、ArtifactType、PublicRationale 契约、递归排序稳定序列化 + SHA-256、确定性产物 ID、幂等持久化（onConflict 回读）、运行产物链读取、execution manifest 散列、producer 元数据（model/promptHash/settingsHash）。
- 新增 `server/runs/snapshots.ts`：run_start 快照在 createStudyRun 时固化并回写 start_snapshot_id（修 G7 导出语义）；generation_end 快照在发布收尾固化。
- executor 改造：十个节点全部在成功前持久化主产物（learner_snapshot/evidence_set/domain_brief/resource_draft/claim_audit/challenge_set/adjudication/privacy_decision/publication_decision），下游 inputRefs 引用上游产物 ID；修订轮走 attempt+1 产物不覆盖旧轮；上传正文只存文件名/字节数/散列；发布收尾计算 execution manifest hash。claims 落库带 runId/attempt/draftArtifactId。
- 路由：新增 `GET /api/learning/runs/:runId/trace`（DAG+artifact+Claim 图+质询+裁决+快照，learner 双重校验）；export 修正——initialLearnerState 取 run_start 快照（历史运行回退现查并如实标注 source）、artifact 清单+散列+producer、Claim 按 attempt 分组、EvidencePack 快照、执行清单散列、上传正文替换为审计元数据（脱敏）。
- 验证：typecheck 0 错误；测试 18 文件 / 121 用例全过（新增 artifacts 契约 6 用例：稳定序列化、单字符变化散列必变、产物 ID 确定性、执行者覆盖）；pnpm db:migrate 应用成功。
- 未发生网络下载与 live 模型调用。

## 2026-08-29 里程碑 A 完成：基线冻结与流量保护

- 工作区改动确认（`git status --short`）：用户未提交改动为 findings.md / progress.md / task_plan.md（升级规划记录）、删除 `sol的第一份计划.md`、新增 `docs/挑战杯多智能体可信协同升级计划.md`；全部保留未覆盖，本轮未改动任何无关文件。
- 服务与数据状态：PostgreSQL / Redis 容器 healthy（15432 / 16379），api(3001) 与 web(3000) 常开运行中；MetroPT-3 数据与嵌入已在库，未重新拉镜像、未重新导数据。
- 基线验证：`pnpm typecheck` 0 错误（5.5s）；`pnpm test` 17 个测试文件 / 115 用例全部通过（3.2s）；`pnpm-lock.yaml` 无变化。
- 流量保护约定落位：`.env.example` 新增 `IM_TRAINING_AGENT_ALLOW_LIVE_EVAL=false`（默认关闭），并注明打开前必须先说明预计案例数与调用量、取得用户授权；本轮未发生任何网络下载与 live 模型调用。
- 下一步：里程碑 B（VACP 产物层与起止快照）——schema 增补 `collaboration_artifacts` / `run_state_snapshots`、新增 `server/runs/artifacts.ts` 与 `server/runs/snapshots.ts`、executor 节点产物化、Claim 补 attempt/draft 关联前置。

## 2026-08-29 挑战杯多智能体可信协同升级计划

- 完整重读 `挑战杯.md`：确认满分要求集中在完整闭环（30）、技术创新（25）、用户体验（15）和实用价值（30）；实用价值高分线要求 ≥3 画像、完整测试方案、幻觉率 <5%、难度适配 ≥85%、核心知识覆盖 ≥90%，且低档说明明确提到测试用例不足 50 组会扣分。
- 复核当前实际代码：动态 DAG、BullMQ、SSE、BKT、难度校准、混合检索、Claim 审核、独立批评、证据裁决、六类资源均已落地；当前 115 个测试与 TypeScript 检查通过。
- 明确主要缺口：`context_json` 会覆盖修订轮中间产物；Claim 缺 attempt/draft 关联；运行前画像快照语义不正确；planner 运行时信号较粗；覆盖率仍有关键词判定；现有 live 报告仅 9 个分层案例；消融报告没有初稿幻觉率与真实修订增益。
- 形成核心创新：VACP 可验证 Agent 协同协议，以及“学情图—声明证据图—协同运行链”架构；通过不可变 artifact、公开理由、输入引用、内容散列、离线 replay、反事实画像对照和消融实验形成可供第三方验证与借鉴的方法。
- 前端方案锁定为小改：保留现有三个工作台，顶部新增“验证”页面；路径页补决策依据，学习页补节点公开产物，资源页补 provenance 和反馈影响，画像补 before/after。
- 新增详细执行文档 `docs/挑战杯多智能体可信协同升级计划.md`，覆盖硬约束、差距审计、目标协议、数据/API、八个里程碑、测试矩阵、指标口径、材料清单、风险与完成定义。
- 流量约束已写入计划：本次规划未联网、未安装依赖、未下载数据或模型、未执行 live 模型评测。

# 2026-08-29 总规阶段一~五主体执行：PG 单数据源 + 诊断/画像/苏格拉底 + 混合检索/批评裁决 + 评测交付

- 阶段一A/B：未提交的用户自传头像工作收口——PATCH /api/auth/avatar-image、users.avatar_image（SQLite ensureColumn + PG 迁移 0003）、共享 ProfileDialog，三个工作台顶栏统一 AvatarBubble 消费 avatarImage；清理一次性脚本与根目录旧 .next；前端 .next 缓存损坏导致的 GET / 404 已排查修复（清缓存重启）。
- 阶段一D（核心）：PostgreSQL 单数据源切换落地。新增 server/db/pg-store.ts（PgIdentityStore + PgLearningStore，与 SQLite 版逐方法等价：BKT/诊断/路径/资产/反馈/画像/证据/隐私审计，jsonb 显式序列化避免数组转 PG 数组字面量的坑）与 server/db/pg-evidence.ts（PgEvidenceService + 结构化数据集查询 + 干净环境引导导入）；study-context.ts 数据源开关（DATABASE_URL 即 PG，IM_TRAINING_AGENT_DATA_SOURCE=sqlite 回退）；全部存储调用点补 await（await 对同步实现 no-op，双实现兼容），routes.ts requireLearner 异步化修复 learner_id=undefined 的门禁绕过隐患；IdentityStore 新增 getByLoginName 公共 API 替换 demo-seed 的内部 hack 查询。
- 关键修复：ESM import 提升 + dotenv 时序问题——study-runtime 在 index.ts 的 dotenv.config() 之前求值，DASHSCOPE_API_KEY 为空导致模型 provider 未注册，服务内所有 LLM 调用一直静默走兜底模板；study-runtime/study-context 顶部前置 import 'dotenv/config' 后修复。
- 阶段一C：Compose 全链路补齐——新增 bootstrap 服务（scripts/db-bootstrap.ts：迁移→Metro 目录→AI4I→知识卡→可选 Metro CSV，全部幂等，实测跑通）、web 服务（web/Dockerfile standalone 构建）；tsup 增加 db-bootstrap 入口，Dockerfile 携带迁移 SQL 与引导数据；compose config 校验通过（镜像构建因 docker.io 网络不可达暂缓，待代理重试）。
- --cutover 标记已写入：PostgreSQL 为唯一业务数据源，SQLite 仅作只读备份；PG 实测端到端：注册→建档→诊断→证据→Run 十节点 DAG→门禁发布入库→assets/作答/画像全链路；demo:seed 直接种入 PG（三账号差异化 BKT/LLM 路径/画像）。
- 阶段二A：建档后强制 12 题入学诊断——新增 web/src/components/diagnostic-flow.tsx（逐题作答自动前进、服务端判分、维度小结与逐题解析）；/api/auth/me、login、register、onboarding 统一携带 diagnosticCompleted。
- 阶段二B：GET /api/learning/profile 扩展 blindSpots（BKT 掌握×作答证据排序）/difficultyCurve（难度校准推导，预计成功率落 65-80% 教学区间）/resourceMatch（六类资源适配建议）；新增 GET /api/learning/bkt-updates 审计端点；server/profile-insights.ts 确定性洞见模块；画像弹窗新增盲区/难度曲线/资源匹配三区块。
- 阶段二C：苏格拉底启发式追问全链路——guidance_sessions/guidance_turns PG 表（迁移 0004）、src/learning/socratic.ts 纯函数（关键度×(1-置信度) 选题、终止条件、确定性兜底）、server/guidance-service.ts 编排（LLM 逐轮提问与公开评价、每轮 BKT 更新、置信≥0.8 或 5 轮终止出决策）、两个 API 端点、前端 guidance-dialog.tsx + 路径页节点详情入口；实测 LLM 生成式追问 + BKT 0.357→0.5 实时更新。
- 阶段三A：运行时混合检索——src/learning/retrieval/hybrid.ts（纯 RRF，k=60）+ server/db/pg-retrieval.ts（tsvector 全文路与 pgvector cosine 向量路各 top-20、RRF 融合 top-8）；查询向量 DashScope text-embedding-v4，嵌入失败降级纯 FTS 并把降级原因写入 EvidencePack.hybrid 与 Run 事件/群聊气泡；bootstrap 重导后向量重回填（缓存复用 616/616 零成本）。
- 阶段三B：独立批评 Agent + 裁决 Agent——debate_issues 加 source 列（迁移 0005）；反方质询升级为规则兜底 + LLM 独立批评（检测无证据/冲突/越界因果/难度失配，失败静默回退）；裁决升级为规则裁决 + 裁决 Agent 独立判决取更严者（门禁只能收紧不能放松），rationale 记录双轨；实测批评 Agent 补充 3 条高质量议题（量化支持缺失/未验证因果/难度失配）、双轨裁决一致。
- 阶段四：六类资源端到端扫描全部 succeeded 且门禁通过入库（auditStatus passed + difficultyCalibration 落库）；concept_map 的 Mermaid flowchart 文本在资源页客户端渲染（web 新增 mermaid 依赖动态导入，失败回退代码块）；阅读反馈→预填→作答→BKT→节点建议闭环此前已验证。
- 阶段五：三账号证据包导出 data/exports/{persona}-run-export.json（画像+诊断+DAG 节点+22-23 事件+声明图+裁决+最终资产，差异化任务产出差异化资源）；scripts/ablation.ts 消融实验三组全过——A1 动态 DAG 三画像分化 3 种计划（固定 1 种）、A2 发布资源幻觉率 0（4 次运行）、A3 BKT 校准难度成功率 33/33 落 65-80% 区间（固定 0.42 仅 2/33）；evaluate 支持 --stride 分层采样；pnpm evaluate --live 分层子集验证真实生成幻觉率；findings.md §6 演示分镜按当前产品更新。
- 踩坑记录：node-postgres 会把 JS 数组序列化为 PG 数组字面量导致 jsonb 列写入报错（需显式 JSON.stringify）；drizzle select 返回数组而非 {rows}；export 脚本 grep 节点状态误判运行终态（须锚定 run 对象）；本机 5432 被 PG 占用继续沿用 15432/16379；docker.io 直连不可达影响镜像构建。
- 验证：typecheck 0 错、115 测试全过、前端 tsc/standalone 构建通过；PG 模式全链路冒烟与冒烟数据清理完成。

# 2026-08-28 BullMQ 动态 DAG 全链路 + 个性化算法层（8/30-9/3 日程主体完成）

- 模型运行时与数据层引导抽为共享模块：server/study-runtime.ts（模型注册/角色路由/发布门禁）、server/study-context.ts（SQLite 打开与存储实例），api 与 worker 进程同源不再复制；index.ts 两段纯搬移并验证启动。
- runs 模块落地：queue.ts（BullMQ，jobId=runId:nodeKey:attempt 幂等、重试≤2、指数退避）、service.ts（study_runs/nodes/run_events 持久化，jsonb 原子合并 context，单条 SQL 原子分配单调 seq）、executor.ts（十节点执行器：双路检索并行→领域分析→生成→Claim 审核→反方质询→证据裁决→隐私→发布；修订环最多 2 轮；裁决落 audit_decisions，质询落 debate_issues，Claim 落 claims/claim_evidence）、worker.ts（独立进程，并发 4，优雅退出）。
- SSE 事件流：GET /api/learning/runs/:runId/events 支持 Last-Event-ID 断点续传（PostgreSQL 回放 + Redis 实时分发）；POST /runs 返回 202+plan；快照/取消接口齐备；门禁角色 custom 模式下真实裁剪且不可移除。
- 前端切换：学习页 submit 改 POST /api/learning/runs，EventSource 驱动实时节点状态条（运行中/成功/失败/修订中），终态拉全量历史替换；旧 study/chat、activeStudyRuns、进程内 executeStudyRun 同批删除；指定角色补"资源生成"并校验 ≥3 业务角色。
- 个性化算法层（纯函数+测试）：bkt.ts（贝叶斯修正+学习转移+证据量置信度，n=9 过 0.80 门限）、difficulty.ts（成功率模型 p̂=readiness+support·(1-d)−0.2d，目标 72%，区间 65-80%）、diagnostic.ts（12 题五维固定题集+判分+BKT 初始状态）。初稿难度模型在"初学者×高脚手架"方向反了，已重导并按教学原则重定评测区间。
- 存储层：SQLite 补 BKT 参数列/bkt_updates/诊断表/资产难度列（ensureColumn 迁移兼容）；submitQuizAttempt 的启发式更新替换为 BKT；新增 applySkillObservation/getSkillState(s)/saveDiagnosticSession；saveAsset 落 difficulty+calibration。
- D2 修复完成：资源构建链接 calibrateDifficulty（executor 按资源类型定脚手架、按路径边算先修就绪度），实测"初学者×习题"校准难度 0（原 0.42 硬编码），rationale 完整落库。
- 诊断 API：GET /api/learning/diagnostic（不下发答案）、POST /api/learning/diagnostic-attempts（服务端判分→BKT→诊断会话落库→解析回放）。
- 三账号种子：pnpm demo:seed 幂等创建 learner-foundation/advanced/maintenance，确定性诊断作答（5/12、10/12、8/12）驱动差异化 BKT 初始状态；密码只从 IM_TRAINING_AGENT_DEMO_PASSWORD 注入。
- 证据包导出：GET /api/learning/runs/:runId/export 单文件 JSON（画像+诊断+DAG 节点+事件+结论+声明图+资源+反馈）。
- 评测器：pnpm evaluate 离线模式 60 案例（三画像×20，确定性生成）→ 难度适配 100%、核心知识覆盖 100%（教学区间独立设定、覆盖按知识库包含检查）；幻觉率需 --live 模式执行真实运行；结果落 evaluation_cases/results，报告写 data/。阈值不达标退出码 1。
- 踩坑记录：本机原生 PostgreSQL 占 5432 导致容器连接串认错服务（改 15432/16379）；新旧 worker 进程并存抢任务导致看到旧代码产物（全杀重启后验证通过）；drizzle-kit migrate 静默退出改用编程式 migrator。
- 验证：typecheck 0 错、115 测试全过、tsup（含 worker 入口）与 Next 构建通过；端到端两次真实运行（讲义 10 节点全过资产入库；习题校准难度落库）；SSE 续传实测 id 21/22 精确回放；服务 3000/3001 已重启。

# 2026-08-28 挑战杯总规落地：平台基础设施与 SQLite→PostgreSQL 迁移（8/28-29 日程提前完成）

- 按 sol 的第一份计划产出唯一技术总规 `docs/挑战杯技术开发总规.md`：现状审计（D1-D7 缺陷含 selectedAgentIds 假交互、difficulty 0.42 硬编码、进程内 Run 无持久化）、目标架构、API 契约、九组领域表、BKT/难度校准/苏格拉底/混合检索算法、迁移流程、任务顺序与量化验收。
- 新增 docker-compose.yml（pgvector/pg16 + redis7，api/worker 为 full profile）+ Dockerfile + deploy/db/init 扩展脚本；用户已将 Docker Desktop 安装至 D:\ZPan\docker（数据盘随之在 D 盘）。
- 本机原生 PostgreSQL 占用 5432 导致连接串认错服务，容器端口改映射 15432/16379 并写入 .env；PostgreSQL + Redis 容器 healthy 运行。
- drizzle：server/db/schema.ts 落地九组领域表（含 document_chunks 1024 维 vector + GIN 全文 + HNSW 索引、study_runs/study_run_nodes/run_events、claims/debate_issues/audit_decisions、evaluation_cases/results）；drizzle-kit migrate 在本机静默退出，改用编程式 migrator（scripts/db-migrate.ts）。
- 新增幂等迁移程序 scripts/migrate-sqlite-to-pg.ts：源库只读、指纹幂等跳过、分批 COPY（5000 行/批）、表级行数校验、Metro 时间边界校验、源 CSV SHA256（缺失时如实标注数据准备状态）、迁移报告 JSON、--dry-run/--force/--cutover。
- 真实迁移完成：26 表全部校验通过，metro_readings 1,516,948 行（47 秒），时间边界源目标一致；幂等重跑 26 表全部跳过；claims.learner_id 由 learning_assets 回填成功。
- 新增 server/runs 协议与动态 DAG 编排器：StudyRunRequest/StudyRunPlan/RunEvent/SSE 帧格式；planStudyRun 纯函数（auto 全链路 + 风险信号从严；custom 模式 selectedAgentIds 真实裁剪业务节点、业务角色 ≥3 且资源生成不可取消、四个门禁节点不可移除）；validatePlan 校验依赖闭合/无环/门禁齐全；6 个单元测试。
- isLearningResourceType 收口到 src/learning/types.ts 作为唯一定义；tsconfig typecheck 范围扩至 server/db、server/runs、scripts（server/index.ts 存量严格模式错误不在本轮范围）。
- 验证：类型检查 0 错误、101 测试全过、tsup 与 Next 构建通过；3001/3000 服务已重启正常；迁移后运行数据源仍为 SQLite，`--cutover` 待人工确认执行。

# 2026-08-28 产品边界与旧包袱收口完成

- 前端入口从 3745 行旧通用工作台收敛为精简产品壳，只保留登录、路径、协同学习和资源学习；移除不可达代码与 `@ts-nocheck`。
- 服务端移除旧 `/api/sessions/*`、通用聊天/澄清、WebSocket、会话文件存储及对应测试；通用多智能体模块继续作为内部库保留，不再暴露未鉴权产品入口。
- `/api/learning/*` 与 `/api/settings/*` 统一要求 Cookie 登录；证据列表按 learnerId 经 EvidencePack 关系过滤，并新增隔离测试。
- pnpm workspace 正式纳入根项目与 `web`，删除两份 npm lockfile；补齐 `tsx`、esbuild 与 sharp 的 pnpm 构建声明。
- 增加 `pnpm data:metropt`：从 UCI 官方源下载并校验 MetroPT-3，仅解出被 Git 忽略的 CSV；后端发现 CSV 后自动导入 SQLite。没有完整数据时保留 AI4I 与 MetroPT-3 文档证据运行能力。
- 验证：根/前端 TypeScript 检查通过，95 个测试通过，后端 tsup 与前端 Next 生产构建通过；3000/3001 服务已重启。匿名访问学习/设置接口返回 401，旧 sessions 接口返回 404。

- 已完成：项目文件初步盘点；确认前端入口、工作流、编排、记忆、会话存储和测试目录。
- 已完成：阅读项目说明、`CLAUDE.md`、前端入口、服务端路由、会话存储、深度规划、Agent 集群、评估器、记忆和工具层。
- 已完成：确认当前系统的真实能力边界与学习产品缺口。
- 已完成：整理最小学习闭环、页面职责和后续开发顺序。
- 已完成：核对用户提供的六大资源架构；确认其中 SQLite、EvidencePack、Claim 审计等属于目标设计，当前代码尚未完整落地。
- 已完成：检查数据包样本；确定 MetroPT-3 作为首个主数据源，AI4I 作为可解释基准，用户上传资料默认只做临时参考。
- 已完成：收敛 RAG 分层：CSV/时间窗口走 DuckDB，文档走全文/向量检索，统一输出 EvidencePack，再驱动资源生成和审计。
- 已完成：当前实现使用 SQLite 持久化学习资产、学习事件、路径节点和画像快照；MetroPT-3 通过 SQLite 精确查询，文档通过 FTS5 检索。
- 已完成：学习任务会调用模型生成路径并替换右侧“路径”数据，同时保存讲义、分层练习和知识图谱三类资产。
- 已完成：输入框保留临时参考文件与协同方式；模型与 low / medium / high / max 思考深度由设置中的系统默认和角色覆盖统一控制。
- 已完成：左侧智能体卡片和中间过程消息支持展开，展示任务、状态和工具调用记录。
- 已完成：画像支持 SQLite 快照、关键词、雷达指标，以及学习时间、资产数、今日资产数、正确率等代码统计指标。
- 验证：后端类型检查、tsup 打包、前端 Next 生产构建、93 个自动化测试均通过；本地服务保持运行在 3000 / 3001。
- 已完成：三栏增加左右拖动分隔线，左侧协同栏可收起到屏幕边缘，右栏横向溢出已隐藏。
- 已完成：RAG 统一输出 EvidencePack；CSV 走 SQLite 精确查询，MetroPT-3 PDF 走 FTS5 文档检索，并保留数据集、字段和页码定位。
- 已完成：交叉验证位于“检索 → 生成 → Claim 审核 → 保存资产”之间；同时检查双来源、定位完整、声明覆盖和数字一致性，未通过的资源不标记为已审核资产。
- 已完成：用户上传资料只作为当前会话临时参考，记录文件名、大小和哈希审计信息，不写入系统知识库、不保存原文；证据右栏展示来源、方法、可信度和定位。
- 已完成：模型服务支持多服务入口、模型自定义名称、low / medium / high / max 思考深度；系统默认执行模型与深度可核验，输入框不再重复设置。
- 已完成：按模式职责配置选择学习 Agent，包含交叉验证与合规审计角色，不再从通用 Agent 数组按顺序截取。
- 已完成：设置弹窗顶部切换四页：模型服务、协同编排、学习资产、本地数据。协同编排固定六个职责角色，逐角色可继承明确的系统默认模型/深度或指定覆盖；检索职责覆盖 CSV 查询与 PDF 检索，审核与隐私角色为发布前固定关卡。
- 已完成：交叉验证与 Claim 审核固定为发布前关卡，未通过的资源不入库；学习资产页真实控制任务后自动生成讲义、分层习题、知识图谱三类产物；本地数据页展示并可清除不含原文的临时资料审计记录。
- 已完成：右栏固定为计划、流程、任务、结果、路径、画像、资产、证据八个入口；协同方式移至输入框控制，避免与系统执行模型重复。
- 验证：后端类型检查、tsup 打包、前端生产构建、93 个自动化测试、API EvidencePack 检索与资源 Claim 审核均通过；服务继续运行在 3000 / 3001。
- 已完成：从产品经理视角收敛首期垂直场景、用户旅程、动态 Agent DAG、资源渲染与 SQLite/JSON/文本数据分层；后续实现以首次诊断、当前行动、作答事件和路径动态调整为主线。
- 已完成：真实账号注册、登录会话和首次画像建档；建档后由路径规划智能体生成第一棵可分叉知识路径，节点与边、用户“学完/掌握”状态均持久化至本地 SQLite。
- 已完成路径页第一版重构：当前页明确为路径页，左侧是路径调整对话，右侧上方按真实边关系绘制知识树、下方展示选中节点详情；节点点击带入对话，学完/掌握/新增前置或分支均进入真实交互链路。
- 已确认学习页下一版职责：三栏分别是总控 Agent 与动态子 Agent、协同对话与资源生成过程、与路径页共用的当前学习路径；资源正文不在学习页展开，统一转入资源页。
- 已完成学习页第一版：三栏可调宽度；总控 Agent 和按任务生成的子 Agent 可展开查看任务、工具和结果摘要；中栏通过显式 `@` 引用路径节点，选择六类资源后走真实检索、资源生成、Claim 审核、交叉验证和隐私关卡；已审核资源持久化后可导出 MD、TXT、JSON。
# 2026-08-27 资源页实施中

- 已确认资源页的数据缺口：分页笔记、习题尝试与掌握等级需要新增 SQLite 实体和受账户隔离的接口。
- 正在实现讲义阅读与习题作答两个子界面；其它四类资源先使用同一资产目录入口，避免先做无法使用的展示页。

# 2026-08-27 资源页第一版完成

- 资源页已作为第三个主页面接入：左侧可收起的资源类型/目录，中间阅读或作答区，右侧随当前讲义页或当前题变化的笔记/解析区。
- 讲义支持章节跳转、前后翻页、页级笔记、三档掌握反馈、MD 导出和资产删除。
- 习题支持题号跳转、后端判分、答案解析、逐次尝试历史与实际耗时记录；判分会更新知识点的练习次数、正确次数、掌握度和置信度。
- SQLite 已新增 `learning_asset_page_notes` 与 `learning_quiz_attempts`，既有旧习题在读取时会兼容为可交互的选择题格式。

# 2026-08-28 路径节点建议闭环完成

- 修复闭环断点：学习资产的知识点 ID 不再硬编码为 compressor-diagnosis-evidence，学习页按节点生成的资源会绑定当前路径节点的 knowledgePointId，作答数据因此能落到对应节点的技能状态上。
- 路径节点新增证据驱动的 recommendation：确定性规则从 learner_skill_states（作答次数、正确率、掌握度）与讲义掌握反馈推导“建议补强 / 保持节奏 / 可进阶 / 暂无记录”，理由携带真实数字；节点用户状态仍只由用户手动标记，符合既定设计。
- 路径页与学习页的知识树节点显示建议标记点，节点详情展示建议徽标与理由，路径页图例同步更新。
- 验证：后端类型检查、99 个测试（新增 computeNodeRecommendation 6 个用例）、前端生产构建通过；API 冒烟验证“注册→建档→挂节点生成习题→6 次作答→节点建议升级为可进阶、未学节点保持暂无记录”全链路，冒烟账号与数据已清理。

# 2026-08-28 数据层范式与讲义升级完成

- 数据层做成可替换范式：data/knowledge/*.md 丢弃式知识卡自动入库（首批 14 张：Python/pandas/清洗/时序/统计/可视化/AI4I 字段与故障机理/证据边界/阈值法）；tabular.ts 提供 importCsvDataset（SHA256 校验和，文件变更自动重导入）+ dataset_rows 通用表格层 + 按标签抽代表性样本。
- AI4I 2020（1 万行、6 个故障标签字段）作为入门教学数据集接入 data/datasets/ai4i/；MetroPT-3 仍是时序主数据，两者共存于同一证据层。
- 修复存量检索 bug：FTS 虚表查询引用了不存在的 source_id 列导致一直在走 LIKE 兜底，旧卡永久挤占检索名额；现回联原表并按 bm25 相关度排序。
- 讲义模板升级：新增 code 块（pandas 代码示例）与 table 块（代表性数据摘录，主标签列在前、带可回溯定位，按主题关键词自动选数据集）；资源页渲染器与 MD 导出同步支持；audit 对 code/table 免 Claim 审核。
- 根治前端构建对 Google Fonts 的网络依赖（改为系统字体栈），离线可构建。
- 验证：类型检查 0 错误、99 测试全过、前端生产构建通过；冒烟验证 Python 主题讲义（此前必被门禁拒发）现在通过审核入库，含 AI4I 故障样本摘录表；压缩机主题仍走 MetroPT-3 时序摘录。冒烟账号已清理。
- findings.md 精简为决策记录，写入三组差异化测试账号方案与 10 分钟视频分镜脚本。

# 2026-08-28 学习页真实多智能体群聊协同完成

- 承认并替换了旧的假协同：study/chat 原来一次请求内用固定文案冒充智能体活动、资源纯模板生成、没有任何模型调用。
- 新协同 Run：总控编排 → 双检索实例真实并行（SQLite 结构化 + FTS 文档）→ 学情与路径智能体（LLM 读真实画像/技能状态，失败回退确定性文案）→ 领域诊断（LLM，引用证据）→ 资源生成（讲义/实操走 LLM 正文 + buildLlmResourceDocument 组装章节/代码/数据摘录/证据块）→ 逐条 Claim 审核 → 隐私合规 → 总控收尾。每个智能体的发言真实写入聊天记录，前端 1.2 秒轮询逐条冒泡呈现。
- 新增审核回退环：第一轮门禁未过（数字无法核对）→ 审核打回 → 生成端按 failedClaims 修订 → 复审；修订后仍不过用内置模板兜底，保证有证据时演示必出资产。冒烟已验证“第一轮打回 → 修订 → 复审 23/23 全支持”真实发生。
- 同类智能体多实例落地：知识检索 Agent · 结构化 / · 文档两个实例各自汇报命中与定位。
- 学习页三栏重定义：左栏=任务上下文（当前节点+建议徽标+学情快照+本次任务配置）；中栏=协同群聊（用户右侧深色气泡，智能体带角色头像逐条冒泡，进行中指示器，历史完整回放）；右栏=路径树+节点详情（不变）。
- 资源页讲义分页升级：标题块开启新页并跟随正文，代码/表格/证据/习题独立成页；标题块获得渲染样式。
- 验证：根类型检查 0 错、99 测试全过、Next 构建通过；端到端冒烟两次（一次触发修订环 70 秒、一次一轮通过 67 秒），资产含 LLM 章节 + Python 代码块 + AI4I 数据摘录表。冒烟账号已清理。

# 2026-08-28 设置统一入口与内容重构

- 设置入口统一为三个页面顶栏最左侧的「设置」按钮（路径/学习/资源），点击弹出设置窗口；路径页左下角的旧入口移除。
- 设置弹窗抽为共享组件 settings-dialog.tsx，四页签：模型服务（Provider 管理 + 默认执行模型/思考深度）、协同编排（六角色逐角色模型/深度路由，标注检索双实例与审核/隐私固定关卡）、学习资产（自动生成类型开关）、数据与隐私（真实接通隐私审计记录查询/清除 + 固定边界声明，原来只是静态文案）。
- 设计原则：设置只放真实改变系统行为的运行时配置；审核与隐私门禁明确标为不可关闭的固定项，不做假开关。

# 2026-08-28 资源页悬浮类型导航

- 按用户设计收敛资源页左侧交互：移除“点按钮滑出资产目录面板”方案，改为鼠标贴到屏幕最左缘自动浮现的类型导航（六类资源 + 各自数量，选中后自动收回）。
- 资产目录不再占用侧边栏：阅读区顶部新增资产选择条（类型徽标 + 同类型资产下拉 + 删除按钮），阅读器自身的章节/导出控件保持不变。

# 2026-08-28 阅读反馈接入补强闭环

- 资源页反馈区不再止步于三档掌握反馈：新增“按这份讲义/资源的薄弱点生成练习”按钮，一键携带资源标题、掌握反馈与知识点跳转到学习页。
- 学习页消费预填任务：自动填入任务草稿、切换资源类型为分层习题、按知识点自动关联路径节点，用户确认后即可发起针对性协同。
- 闭环补全：讲义反馈 → 针对性练习 → 后端判分 → 技能状态 → 路径节点建议，反馈从死胡同变成学习循环的入口。

# 2026-08-28 知识库大规模充实：官方文档抓取管线 + 切块 + 向量回填

- 针对知识库过薄的问题（此前仅 ~37 条手写切片）建立可重复的抓取管线 `scripts/ingest-docs.ts`（pnpm docs:ingest）：抓取权威公开文档 → 主内容抽取（node-html-parser 多选择器 + 去 script/侧栏/¶锚点）→ Markdown 化（node-html-markdown）→ 围栏感知逐行清洗（去图片/链接语法/导航句）→ frontmatter 卡片落盘 data/knowledge/。
- 数据来源 15 个全部入库：pandas 用户指南 6 篇（10min/索引/分组/缺失数据/时间序列/滑动窗口）、matplotlib 3 篇（pyplot/快速上手/直方图）、Python 官方教程 3 篇（控制流/数据结构/异常）、scikit-learn 离群检测（含孤立森林）、UCI API 2 个数据集（AI4I-2020、MetroPT-3：绕开页面对直接抓取的 403，改用官方 JSON API 拿结构化元数据——简介/字段表/引用论文；MetroPT-3 正确 ID 是 791）。
- 知识导入器升级（src/learning/knowledge-import.ts）：1 卡 = 1 切片改为按 `##` 章节切块（≤1200 字符装箱、代码围栏不从中截断、<160 字符碎片并入前片、切片标题携带章节锚点），幂等整体重导。
- TERM_ALIASES 新增 20+ 中文→英文检索别名（直方图/箱线图/滑动窗口/缺失值/分组/重采样/孤立森林/索引等），FTS 'simple' 分词器无法切中文的问题由别名桥接。
- `scripts/embed-documents.ts`（pnpm docs:embed）：SQLite 受管切片全量同步 PG document_chunks（含 search_text），DashScope text-embedding-v4 1024 维向量回填，按 sha256(正文) 做缓存（data/embeddings-cache.json，已 gitignore）避免重复计费。
- 结果：SQLite document_chunks 616 条（knowledge-cards 593 + metropt-3 目录 23）；PG 全量同步且 616/616 带向量。中文语义检索冒烟（"缺失值/直方图/滑动窗口/孤立森林"）余弦命中对应官方文档章节 0.63-0.78；FTS+别名路径同样全中。
- 验证：pnpm evaluate 难度匹配 100%、覆盖 100%（现在建立在真实语料上）；typecheck 0 错、115 测试全过；服务与 worker 已重启加载新语料。

# 2026-08-28 浏览器实测三演示账号 + 演示链路打磨

- 用浏览器内测工具全程 UI 实测：登录 → 建档 → 路径 → 学习页，三个演示账号全部通过。
- 修复一：demo:seed 对已存在账号原来只复用不更新密码，换环境后旧密码失效；新增 IdentityStore.resetPassword，种子时把密码幂等同步为当前 IM_TRAINING_AGENT_DEMO_PASSWORD。
- 修复二（演示主缺陷）：saveOnboarding 会把建档标志置 1，而种子不生成路径 → 账号登录后是"已建档但无路径"的死胡同。把首次路径生成逻辑（generateInitialPathGraph/fallbackPathGraph/normalizePathGraph）从 server/index.ts 抽为 server/initial-path.ts 共享模块，demo:seed 现在以 90 秒预算为每个账号预生成 LLM 个性化路径（超时回退内置 15 节点树）。
- 实测差异化（LLM 定制路径，非回退树）：foundation 13 节点从"Python 变量入门"起步；advanced 12 节点直上 FFT/tsfresh/孤立森林/LSTM 自编码器/多算法比较；maintenance 14 节点走 SQL 日志/诊断决策树/结构化报告模板。
- 浏览器实测注册流：注册 → 建档向导 → 工作台 15 节点路径，全链路通（建档端点 12 秒预算内 LLM 不及则回退内置树，现场演示即时可用；已留 live-demo 账号作为新用户全流程演示）。
- 环境注意：.env 中含 # 的值必须加引号（dotenv 把 # 当行内注释），演示密码已改为带引号的 Zbt2026-Demo-Learner。
- 验证：typecheck 0 错、115 测试全过、服务/worker 重启后登录正常。

# 2026-08-28 深度审计：旧平铺路径系统全套退役

- 审计结论：quiz 判分 BKT 链路、检索 FTS→LIKE 回退、难度校准（0.5 兜底 + calibration 覆盖）、web 组件引用、npm 依赖全部核验无误；真正的旧包袱是**旧版同步生成管线**（前端零调用）。
- 删除三个死端点：GET /api/learning/path（旧平铺路径）、POST /api/learning/context/sync（旧同步全量生成，绕过 DAG）、POST /api/learning/resources/generate（单资源旁路，绕过难度校准）。
- 删除孤儿代码：generateLearningPath/fallbackPath/normalizePathItems/GeneratedPathItem、LearningStore 的 ensureInitialPath/replacePath/getPath、LearningPathItemView 类型、resource-builder 孤儿 import。
- 数据层退役：SQLite 停建 learning_path_items 并在初始化时 DROP 遗留表；PG schema 移除 learningPathItems，新增迁移 0002_drop_legacy_path_items（DROP TABLE IF EXISTS）并已应用；sqlite→pg 迁移脚本同步移除该表映射。
- 保留项说明：socraticPriority（苏格拉底多轮功能原语，有测试）；AUTO_ASSET_TYPES（设置页在用）。
- 回归：typecheck 0 错、115 测试全过；重启后已删端点 404（无 cookie 时被登录中间件 401 先拦属预期）、path-graph/profile 正常、浏览器抽查路径页 15 节点正常渲染。

# 2026-08-30 用户反馈收口

- 设置与隐私：移除 SQLite 静态描述，改为展示实际 PostgreSQL 数据源、记录数量、导出入口和审计清理操作。
- 画像与头像：头像可直接点击更换；画像更新无新增学习证据时保持不变，更新按钮居中并展示结果。
- 协同与路径：公开协同事件在运行完成后继续保留；路径页协同活动默认展开，展示可审计的动作摘要。
- 资源与验证：资源类型收敛为讲义、习题、PPT、知识脉络，新增资源问答；验证页三张辅助卡片明确说明前后对照、离线校验和证据包导出的用途。
- 验证：类型检查、测试、前端生产构建、浏览器回归通过；3000/3001 服务保持运行。

# 2026-08-30 验证页与头像稳定性

- 验证页去掉运行 UUID 和页眉重复标题；导出区改成更克制的说明，前后对照改为轮次与快照状态指标。
- 验证策略展示证据覆盖、校验强度和附加约束数量，数据来自当前运行产物。
- 修复头像更新接口未附带 `diagnosticCompleted` 导致主页面误切回诊断流程的问题；补充图片格式、大小、解析和尺寸校验。
- 回归通过：`pnpm typecheck`、`pnpm --dir web build`，未登录访问设置/学习接口返回 401 且服务保持运行。

# 2026-08-30 学习空间与资源体验打磨

- 学习证据回流：讲义掌握反馈、习题提交和资源完成记录会广播证据更新事件；路径页与学习页在事件、窗口聚焦和运行结束时重新读取路径/画像，推荐状态不再停留在旧快照。
- 协同方式说明：指定角色模式增加实际使用场景与保留审核/检索关卡的说明；左侧“本次配置”改为目标节点、产物、角色数和运行状态等动态信息。
- PPT 闭环：生成提示明确按幻灯片组织，资源页提供逐页演示阅读和 PPT 下载；服务端导出 PowerPoint 可打开的演示稿文件。
- 阅读体验：资源目录改为更接近知识库的文件树层级，讲义与智能体消息支持标题、列表、引用、加粗和行内代码；笔记面板说明记录价值、显示字数，并保留到资源级笔记。
- 回归通过：`pnpm test`（163 项）、`pnpm typecheck`、`pnpm --dir web build`、`git diff --check`。

# 2026-08-30 验证页导航统一

- 验证页顶部导航与路径、学习、资源页统一：设置与画像回到中间导航，退出回到右侧独立入口，避免验证页出现另一套布局和位置跳变。
- 画像弹窗在验证页恢复可用，并沿用头像入口和用户状态更新逻辑。
- 回归通过：验证页浏览器抽查、`pnpm typecheck`、`pnpm --dir web build`。

# 2026-08-30 验证信息与画像标签调整

- 验证页“比赛证据包”改为“证据包”，移除不必要的比赛语境。
- 画像关键词改为从自述中提取短标签，并结合已记录知识点；不再把整段自述或“专业知识学习”这类泛化文案当作关键词。
- 协同运行状态继续保留在学习对话流中，运行结束后仍可复盘。
- 协同过程持久化：学习页刷新或从其他页面返回后，会从最近一次运行的 trace 恢复节点状态和公开摘要，不再只依赖当前页面挂载状态。

# 2026-08-30 提示词体系重写与富文本渲染升级

- 新增 `server/prompts.ts` 作为全部对模型系统提示词的唯一事实源：资源生成（按讲义/PPT/习题/知识脉络分型 + 修订轮变体 + 证据稀疏约束）、学情分析、领域分析、独立批评、证据裁决、路径页协同对话、资源问答、苏格拉底追问（提问/评价）、首次建档路径规划。所有提示词统一了 JSON 契约、数字纪律（数字必须能在证据原文定位，否则 Claim 核验拦截）与中文风格约束。
- 四种资源全部接入 LLM 结构化生成（此前习题/知识脉络走固定模板）：讲义 = 导语 + 4-6 节 Markdown 正文 + 代码示例 + 记忆点 + 常见误区 + 自测问题；PPT = 封面页 + 6-8 页要点 + 每页讲解词；分层习题 = L1/L2/L3 情境化单选题 6-9 道 + 依据引用解析；知识脉络 = Mermaid 图 + 节点解读 + 推荐阅读路径。`resource-builder` 新增 `parseLlmResourceDraft`/`buildLlmResourceDocument` 分型解析与组装，结构不达标自动回退确定性模板；生成 token 预算按类型提升至 3600-6000。
- 资源问答升级：选中资源优先注入、上下文限长、回答预算 2000，回答按“直接结论 → 依据来源 → 下一步建议”结构输出 Markdown。
- 苏格拉底追问：后续轮次同样携带证据摘要，提问基于上一轮回答递进。
- 前端新增共享富文本组件 `rich-text.tsx`（围栏代码块带复制、Markdown 表格、多级标题、有序/无序列表、引用、行内格式），讲义正文、资源问答、协同群聊统一接入；讲义阅读器章节自动编号 + 渐变色标题锚点 + 学习目标卡；PPT 阅读器重做：封面页版式、要点条目、讲解词分区、页码指示；Mermaid 图改用 base 主题配色并居中展示。
- 新增 `src/learning/resource-builder.test.ts` 13 项测试：四种资源解析校验、块组装与证据绑定、生成→Claim 审核联动（数字一致过门禁、编造数字被拦截、模板兜底）。
- 回归通过：`pnpm typecheck`、`pnpm test`（176 项）、`pnpm build`（server）、`pnpm --dir web build`。

# 2026-08-30 低价值静态小字清理

- 全前端清理硬编码的说明性小字（约 20 处）：这类"系统会如何如何"的静态解释不携带动态信息、干扰视线，全部删除或压缩为一句。
  - 资源页：侧栏"工作区"标签、讲义笔记与阅读反馈的功能说明、通用资源页学习记录说明、空状态两行并一行。
  - 学习页：空状态系统编排流程长段、"指定角色"功能说明块（保留角色 chips）、运行收尾说明句简化。
  - 验证页：前后对照/离线校验/证据包三个区块的副标题、底部重复说明段、空状态与"暂无主产物"文案缩短。
  - 设置弹窗：协同编排页顶部说明横幅删除、思考深度说明压缩为"低更快，高更稳。"。
  - 画像弹窗：画像描述空文案、区块标题里的流程性括号注释删除（保留"目标成功率 65%–80%"这类解释数字的注释）。
  - 诊断完成页元说明、苏格拉底弹窗底部轮次说明与输入框占位符、注册表单说明句删除。
- 保留原则：动态数据、错误提示、带操作引导的一句话空状态全部保留。
- 回归通过：`pnpm --dir web build`、`pnpm typecheck`、`pnpm test`（176 项）。

# 2026-08-30 UI 组件打磨

- 删除路径页左下角"服务正常/服务未连接"状态条及其轮询逻辑（服务状态对学习者无操作价值，异常时接口报错本身就有提示）。
- 习题作答升级：选项卡片改为方形字母 chip + hover 阴影过渡；提交后当场标出对错（正确答案绿色高亮、错选红色），题号导航同步；诊断流程选项样式统一为同款。
- 讲义阅读器新增顶部阅读进度条（随滚动填充渐变色细条）。
- 路径树节点卡片加 hover/选中阴影层级。
- 回归通过：`pnpm --dir web build`、`pnpm typecheck`、`pnpm test`（176 项）。

# 2026-08-30 模型切换 OpenCode MiMo 与内容质量修复

- 模型配置：接入 OpenCode Zen（https://opencode.ai/zen/v1）provider，模型 mimo-v2.5-free，设为默认执行模型；所有智能体角色继承默认；思考深度保持 max。端点连通性与鉴权已实测通过。
- 根因修复（"生成模型不可用，已使用内置结构模板"）：资源生成此前受 30 秒调用超时与角色路由输出上限双重挤压，推理模型必然超时回退模板。现拆分 callResourceGeneration 专用通道：超时 200 秒、token 预算按类型 8000-12000（讲义最长）、失败原因写 console.warn 可排障；各节点超时放宽（生成 240 秒、其余 90 秒）；批评/裁决/追问/问答/对话的调用预算与超时同步放宽（推理模型思维段占用输出预算）。
- 讲义升格：提示词要求 6-8 节、每节 400-700 字、全文正文 3000 字以上、至少 2 段可运行代码、按完整教学脉络组织。
- 分层习题三题型：QuizQuestion 增加 type（choice/blank/short_answer）；选择/填空（多候选规范化判分，src/learning/quiz.ts 共享纯函数）/简答（对照参考答案自评）；LLM 生成 9-12 题（每层 3-4 道混合三题型），模板兜底同步扩为 9 题三题型；前端按题型渲染作答界面（填空输入框、简答参考答案对照自评），判分 API 支持 selfAssessed。
- 资源页证据卡清理：结构化数据证据不再逐条输出原始 JSON"数据样本"卡（数据摘录表格已覆盖），只保留领域文档说明卡。
- Mermaid 双保险：生成端清洗节点/边标签内的半角危险字符；前端识别 "Syntax error" 错误图，降级为源码展示不再出现大红错误块。
- 学习页协同状态条置顶 sticky：智能体发言按时间顺序在状态条下方实时追加，跑完不用回翻；路径页对话升级为与学习页一致的卡片样式（头像 + 富文本渲染 + 协同过程卡）。
- 智能体发言更具体：资源生成气泡按类型报告结构（N 节正文约 X 字 / N 页 / N 道题三题型 / 图+解读+路径）。
- 回归通过：`pnpm typecheck`、`pnpm test`（177 项）、`pnpm build`、`pnpm --dir web build`；3000/3001/worker 已重启生效。

# 2026-08-30 界面精简与体验打磨（第二轮）

- 学习页三栏重排：协同运行状态条从中间栏移到左栏（与"当前节点"上下排布），中间栏恢复为纯消息流正常滚动；删除"学情快照""本次配置"两块腾出空间；相应清理 profile/Metric 死代码与冗余接口调用。
- 彻底移除"指定角色"协同模式：下拉、角色 chips、前端校验与请求字段全部删除，协同编排统一交由顶层编排（自动编排即唯一路径，后端默认 auto 兼容）。
- 画像弹窗：删除"移除头像"按钮（点头像即换）；难度匹配曲线/知识盲区标签中文降级链（静态表 → 路径节点标题 → ID），补齐 compressor-diagnosis-evidence 映射，不再出现英文 ID。
- 资源页侧栏删除类型列表头（与类型导航重复）；学习路径节点 description 支持「；」分隔要点自动渲染为无序列表（提示词同步要求 LLM 按 2-3 个要点输出）。
- Code review 收尾：修复 3 处 eslint no-useless-escape；清理全部死代码残留（grep 验证零残留；后端对已删请求字段默认 auto 兼容）。
- 回归通过：`pnpm lint`（0 错）、`pnpm typecheck`、`pnpm test`（177 项）、`pnpm --dir web build`；浏览器实测学习页三栏、画像弹窗、资源页均符合预期。
